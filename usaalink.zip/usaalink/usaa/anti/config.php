<?php
$debug = false;
# Type of Traffic
$spreading = 'adwords';
# Countries Allowed : United States - Spain
$countries_allowed = ["ES", "CO"];
# Langs Allowed : Spanish - English
$languages_allowed = ["EN","ES"];
# Systems to Block
$bad_operate_systems = array("windows nt 6.0",   // Microsoft Windows Vista
    "windows nt 5.2",                            // Microsoft Windows Server 2003 or Win XP x64
    "windows nt 5.1",                            // Microsoft Windows XP
    "windows xp",                                // Microsoft Windows XP
    "winnt5.1",                                  // Microsoft Windows XP
    "winnt5.2",                                  // Microsoft Windows XP x64
    "windows 2000",                              // Microsoft Windows 2000
    "windows nt 5.0",                            // Microsoft Windows 2000
    "winnt5.0",                                  // Microsoft Windows 2000
    "windows nt 4.0",                            // Microsoft Windows NT 4.0
    "winnt4.0",                                  // Microsoft Windows NT 4.0
    "winnt",                                     // Microsoft Windows NT 4.0 or another unknown NT version
//  "windows nt",                                // Microsoft Windows NT 3.5
    "windows ce",                                // Microsoft Windows CE
    "windows me",                                // Microsoft Windows Me (Millennium)
    "win 9x",                                    // Microsoft Windows Me (Millennium)
    "windows 98",                                // Microsoft Windows 98
    "win98",                                     // Microsoft Windows 98
    "win32",                                     // Microsoft Windows 95
    "win95",                                     // Microsoft Windows 95
    "windows 95",                                // Microsoft Windows 95
    "windows_95",                                // Microsoft Windows 95
    "win16",                                     // Microsoft Windows 3.1 or 3.11
    "win3.11",                                   // Microsoft Windows 3.11
    "windows 3.1",                               // Microsoft Windows 3.1
    "win3.1",                                    // Microsoft Windows 3.1
    "cygwin",                                    // CygWin installed over Windows

// ######
// Android OS
    "RazoDroiD",                                 // Custom Android - RazoDroiD
    "MildWild",                                  // Custom Android - MildWild
    "CyanogenMod",                               // Custom Android - CyanogenMod
    "MocorDroid",                                // Custom Android - MocorDroid
    "Fire OS",                                   // Custom Android - Fire OS
    "Silk-Accelerated",                          // Custom Android - Silk-Accelerated
    "TwitterAndroid",                            // Custom Android - TwitterAndroid
    "BeyondPod",                                 // Custom Android for BeyondPOD
    "AntennaPod",                                // Custom Android for AntennaPOD
    "Podkicker",                                 // Custom Android for Podkicker
    "DoggCatcher",                               // Custom Android for DoggCatcher
    "Player FM",                                 // Custom Android for Player FM
    "okhttp",                                    // Custom Android for okhttp
    "Podcatcher Deluxe",                         // Custom Android for Podcatcher Deluxe
    "AliyunOS",                                  // Android - AliyunOS
    "YunOS",                                     // Android - YunOS
    "Android 1.",                                // Android 1.x.x
    "Android 2.",                                // Android 2.x.x
    "Android Eclair",                            // Android 2.x.x
    "Android 3.",                                // Android 3.x.x
    "Android 4.",                                // Android 4.x.x
//    "Android 5.",                                // Android 5.x.x
//    "Android 6.",                                // Android 6.x.x

// ######
// Chrome OS

// ######
// Linux OS 
    "Arch Linux",                                // Arch Linux 
    "BackTrack",                                 // BackTrack Linux
    "CentOS",                                    // CentOS Linux
    "Debian",                                    // Debian Linux
    "Fedora",                                    // Fedora Linux
    "Gentoo",                                    // Gentoo Linux
    "Knoppix",                                   // Knoppix Linux
    "Kubuntu",                                   // Kubuntu Linux
    "Lubuntu",                                   // Lubuntu Linux
    "Maemo",                                     // Maemo Linux
    "Mandriva",                                  // Mandriva Linux
    "Linux Mint",                                // Mint Linux
    "Ordissimo",                                 // Ordissimo Linux
    "Red Hat",                                   // Red Hat Linux
    "RedHat",                                    // Red Hat Linux
    "Sabayon",                                   // Sabayon Linux
    "Slackware",                                 // Slackware Linux
    "SUSE",                                      // SUSE Linux
    "Ubuntu",                                    // Ubuntu Linux
    "VectorLinux",                               // Vector Linux
    "webissimo3",                                // Ordissimo Linux
    "Xubuntu",                                   // Xubuntu Linux

// ######
// UNIX OS
    "AIX",                                       // AIX
    "DragonFly",                                 // DragonFly
    "FreeBSD",                                   // FreeBSD
    "HP-UX",                                     // HP-UX
    "HPUX",                                      // HP-UX
    "IRIX",                                      // Irix
    "IRIX64",                                    // Irix64
    "NetBSD",                                    // NetBSD
    "OpenBSD",                                   // OpenBSD
    "OSF1",                                      // OSF1
    "Solaris",                                   // Solaris
    "SunOS",                                     // SunOS
    "Syllable",                                  // Syllable OS
    "UNIX",                                      // Unix
    "\bQNX\b",                                   // QNX OS

// ######
// Televisions OS
    "AppleTV",                                   // Apple TvOS
    "GoogleTV",                                  // GoogleTV OS
    "WebTV",                                     // WebTV OS

// ######
// Blackberry Bassed OS 
    "BB10;",                                     // Blackberry OS
    "bPod",                                      // Blackberry OS
    "BlackBerry",                                // Blackberry OS
    "QNX",                                       // Blackberry OS
    "PlayBook",                                  // BlackBerry OS
    "RIM Tablet OS",                             // BlackBerry TabletOS

// ######
// Nokia Bassed OS
    "MeeGo",                                     // MeeGo OS
#   "Nokia",                                     // Nokia OS 
    "S60",                                       // Symbian OS 60 Series
    "Series40",                                  // Symbian OS 40 Series
    "Series60",                                  // Symbian OS 60 Series
    "Symbian OS",                                // Symbian OS
    "SymbianOS",                                 // Symbian OS
    "Symbian",                                   // Symbian OS
    "SymbOS",                                    // Symbian OS
    "WeTab",                                     // WeTab OS

// ######
// Palm OS
    "MorphOS",                                   // MorphOS
    "Palm OS",                                   // Palm OS
    "Palm webOS",                                // Palm webOS
    "PalmOS",                                    // Palm OS
    "PalmSource",                                // Palm OS
    "Palm",                                      // Palm OS
    "Xiino",                                     // Xiino OS

// ######
// Mac/iOS
    "; PPC",                                     // PowerPC OS
    "CFNetwork",                                 // Old Mac/iOS
#   "Macintosh",                                 // Macintosh

// ######
// Consoles OS
    "Nintendo 3DS",                              // Nintendo 3DS
    "Nintendo DSi",                              // Nintendo DSi
    "Nintendo Switch",                           // Nintendo Switch
    "Nintendo WiiU",                             // Nintendo WiiU
    "Nintendo Wii",                              // Nintendo Wii
    "PlayStation Portable",                      // PlayStation Portable
    "PlayStation Vita",                          // PlayStation Vita
    "PlayStation",                               // PlayStation
    "Xbox One",                                  // Xbox One
    "Xbox Two",                                  // Xbox Two
    "Xbox",                                      // Xbox
    "KIN.",                                      // Xbox 360 Kinetic

// ######
// IBM OS
#   "OS/2",                                      // IBM OS2

// ######
// Other OS
    "(MTK",                                      // MtkOS
    "Amiga-AWeb",                                // Amiga OS
    "AmigaOS",                                   // Amiga OS
    "AmigaVoyager",                              // Amiga OS
    "Bada/",                                     // Bada OS
    "BeOS",                                      // BeOS
    "Brew MP",                                   // BrewMPOS
    "BrewMP",                                    // BrewMPOS
    "BREW",                                      // BrewOS
    "BMP",                                       // BrewOS
    "Danger hiptop",                             // DangerOS
    "Digital Unix",                              // Digital Unix
    "Haiku",                                     // Haiku OS
    "Inferno",                                   // Inferno OS
    "J2ME/",                                     // Phone Java OS
    "Jolla",                                     // Sailfish OS
    "KaiOS/",                                    // Kai OS
    "Nucleus",                                   // MTK NucleusOS
    "OpenSolaris",                               // OpenSolaris
    "OpenVMS",                                   // OpenVMS
    "RebelMouse",                                // RebelMouse
    "RemixOS",                                   // Remix OS
    "RISC OS",                                   // RISC OS
    "Sailfish",                                  // Sailfish OS
    "ThreadX",                                   // ThreadX OS
    "Tizen",                                     // Tizen OS
    "hpwOS",                                     // webOS
    "webOS",                                     // webOS
);
# Antibots configuration
$comprobate_country = false;
$comprobate_language = false;
$comprobate_bad_os = false;
$comprobate_bots = true;
$comprobate_isp = true;
$comprobate_bad_referer = false;
$comprobate_proxy = false;
?>